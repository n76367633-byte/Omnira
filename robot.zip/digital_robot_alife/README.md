# Digital Robot ALife

An artificial life prototype for a robot that exists inside a small software universe. It is not a chatbot, NPC script, or dialogue system. The robot begins with only primitive needs, sensors, memory, and consequence-based learning. Its behavior emerges from survival pressure, environmental feedback, and accumulated experience.

## What Is Implemented

- Godot 4 project with a visible 2D cybernetic organism.
- Procedural world with walls, resources, charging stations, safe zones, danger fields, temperature zones, energy fields, day/night cycle, weather, resource spawning, and danger evolution.
- Robot body with rotation, movement limits, collision response, damage, repair, fatigue, energy use, and shutdown recovery.
- Sensor system with raycast-like vision, tactile wall pressure, local environmental sensing, resource sensing, danger sensing, and safe-zone detection.
- Internal states: energy, stress, damage, confidence, familiarity, curiosity, fatigue, fear memory, and adaptation level.
- Short-term and long-term memory with decay, reinforcement, spatial tagging, fear/confidence tagging, route traces, and action outcome memory.
- Lightweight reinforcement-learning style Q table using context/action rewards.
- Persistent state saved to Godot `user://organism_state.json`.
- Python headless simulator and validation script for testing the survival/learning loop without Godot installed.

## Run In Godot

1. Install Godot 4.x.
2. Open `C:\Users\Behra\Downloads\digital_robot_alife` as a Godot project.
3. Run `res://scenes/main.tscn`.

Controls:

- `Space`: pause or resume.
- `+` / `-`: change simulation speed.
- `R`: regenerate the world and reset the organism position.
- `F5`: save persistent organism/world state.
- `F9`: load persistent organism/world state.

## Validate With Python

From this folder:

```powershell
py -3 tools\validate_project.py
```

The validator checks required Godot files, basic script balance, project wiring, and a 700-step headless artificial-life run.

## Run Everything In One Animated Window

Use this when you want to see the whole artificial life system at once without opening Godot:

```powershell
py -3 tools\live_alife_observer.py
```

The live observer opens one animated window with the world, robot body, sensor rays, route trail, memory heatmap, needs, learning pressure, Q-table growth, world events, and life traces.

Controls:

- `Space`: pause or resume.
- `Up` / `Down`: change simulation speed.
- `R`: reset into a new world.
- `M`: show or hide memory overlay.
- `S`: show or hide sensor rays.

## Tooling Setup

- Godot: primary simulation engine and visual runtime.
- GDScript: modular organism/world implementation.
- Python: headless behavior validation and future research experiments.
- Visual Studio Code: open this folder and install the Godot Tools extension for script editing.
- Google Antigravity: can open the same folder for code navigation and refactoring if installed.
- NVIDIA Omniverse: best treated as a future visualization bridge. The current prototype is intentionally lightweight for an 8 GB laptop; exporting simulation snapshots to USD should be added after the organism behavior stabilizes.

## Design Philosophy

The organism does not understand language and does not receive scripted personality. It has drives, sensors, memory, and learning pressure. Over time it should become less random, form routes, avoid danger, seek energy, return to known safe places, and display a behavioral identity produced by its accumulated history.
