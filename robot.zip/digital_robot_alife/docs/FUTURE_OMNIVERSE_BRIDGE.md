# Future Omniverse Bridge

The current simulation is intentionally Godot-native and lightweight. NVIDIA Omniverse can become a high-fidelity observer later without taking over the life simulation itself.

Suggested bridge:

1. Add a Godot exporter that writes periodic snapshots:
   - robot position, heading, stress, energy, damage
   - world cell types
   - resource and danger changes
   - memory heatmap values
2. Convert snapshots to USD with Python.
3. Open the USD stage in Omniverse Create or Kit for cinematic rendering.
4. Keep learning and survival inside Godot/Python so the organism remains the source of truth.

This separation keeps the organism efficient on low-end hardware while still allowing Blender/Omniverse-style visualization later.
