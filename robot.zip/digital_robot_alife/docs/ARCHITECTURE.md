# Architecture

## Runtime Loop

Each fixed simulation step follows this order:

1. The world advances aging, light, resources, weather, and danger evolution.
2. The robot senses the environment.
3. Memory records recent observations and reinforces spatial cells.
4. Needs update from energy cost, fatigue, stress, safety, temperature, and damage.
5. The brain scores possible actions from needs, current sensory input, memory, and learned values.
6. Motion applies the chosen movement through collision-aware physics.
7. The environment applies consequences such as charging, resource consumption, danger damage, and repair.
8. The learning system evaluates reward and updates action values.
9. Memory tags the result emotionally and behaviorally.

This keeps the robot from being scripted. Behavior comes from repeated cycles of action, consequence, memory, and adaptation.

## Godot Modules

- `scripts/world/world_simulation.gd`: grid world, procedural generation, environmental dynamics, collision queries, resource consumption, day/night, weather, and rendering.
- `scripts/robot/digital_robot.gd`: organism body, lifecycle, environment consequences, reward evaluation, persistence, and procedural drawing.
- `scripts/robot/needs_component.gd`: biological-like internal state.
- `scripts/robot/sensors_component.gd`: ray vision, local sensing, tactile wall pressure, and directional signal vectors.
- `scripts/robot/memory_component.gd`: short-term events, spatial long-term memory, decay, reinforcement, fear/confidence tagging, routes, and action outcome memory.
- `scripts/robot/learning_component.gd`: context/action Q-style reinforcement values and adaptive exploration rate.
- `scripts/robot/brain_component.gd`: action selection from needs, sensory vectors, memory targets, and learned values.
- `scripts/robot/motion_component.gd`: acceleration, turning, wall sliding, and collision feedback.
- `scripts/ui/simulation_hud.gd`: observational overlay for watching the organism's state.

## Growth Path

The current organism is a baby-like survival learner. The next stages should be added in this order:

1. Stronger world mapping: convert spatial memory into a graph of habit routes.
2. Sleep/rest consolidation: replay recent memories and strengthen useful routes.
3. Sensor uncertainty: add noise, occlusion, and confidence-weighted perception.
4. Evolution experiments: spawn multiple genomes in headless Python and import the best parameters into Godot.
5. Tool/body evolution: make the robot morphology configurable, then let successful body settings persist.
6. Omniverse bridge: export periodic world/robot snapshots as USD for high-end cinematic visualization.

## Performance Notes

The visual world is a small 2D grid with procedural drawing and simple physics. AI computation is dictionary and vector based, with no neural network dependency. This is deliberate so the simulation can run on modest hardware before heavier research systems are introduced.
