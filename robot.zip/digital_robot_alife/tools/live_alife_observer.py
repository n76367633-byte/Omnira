from __future__ import annotations

import argparse
import json
import math
import random
import tkinter as tk
from dataclasses import dataclass, field
from typing import Dict, List, Tuple


EMPTY = 0
WALL = 1
DANGER = 2
SAFE = 3
RESOURCE = 4
CHARGER = 5
HOT = 6
COLD = 7
ENERGY_FIELD = 8

CELL_NAMES = {
    EMPTY: "empty",
    WALL: "wall",
    DANGER: "danger",
    SAFE: "safe",
    RESOURCE: "resource",
    CHARGER: "charger",
    HOT: "hot",
    COLD: "cold",
    ENERGY_FIELD: "field",
}

CELL_COLORS = {
    EMPTY: "#07111d",
    WALL: "#3b4a59",
    DANGER: "#b62945",
    SAFE: "#1d7d78",
    RESOURCE: "#62e0a8",
    CHARGER: "#3f91f7",
    HOT: "#c66a33",
    COLD: "#3f7bc9",
    ENERGY_FIELD: "#7e65e8",
}

ACTIONS = ["explore", "seek_energy", "avoid_danger", "rest", "map_unknown", "return_safe"]
Cell = Tuple[int, int]


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def unit(vector: Tuple[float, float], fallback_angle: float = 0.0) -> Tuple[float, float]:
    x, y = vector
    length = math.hypot(x, y)
    if length < 0.0001:
        return math.cos(fallback_angle), math.sin(fallback_angle)
    return x / length, y / length


def blend_hex(a: str, b: str, t: float) -> str:
    t = clamp(t)
    ar, ag, ab = int(a[1:3], 16), int(a[3:5], 16), int(a[5:7], 16)
    br, bg, bb = int(b[1:3], 16), int(b[3:5], 16), int(b[5:7], 16)
    return "#%02x%02x%02x" % (
        int(ar + (br - ar) * t),
        int(ag + (bg - ag) * t),
        int(ab + (bb - ab) * t),
    )


@dataclass
class World:
    width: int = 64
    height: int = 40
    seed: int = 19
    grid: List[List[int]] = field(default_factory=list)
    resources: Dict[Cell, float] = field(default_factory=dict)
    rng: random.Random = field(init=False)
    age: int = 0
    day_phase: float = 0.18
    weather: str = "clear"
    temperature_bias: float = 0.0
    event_log: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.rng = random.Random(self.seed)
        self.generate()

    def generate(self) -> None:
        self.age = 0
        self.day_phase = self.rng.random()
        self.weather = "clear"
        self.temperature_bias = 0.0
        self.resources.clear()
        self.event_log = ["world booted", "organism awake: no language, only drives"]
        self.grid = [[EMPTY for _ in range(self.width)] for _ in range(self.height)]

        for y in range(self.height):
            for x in range(self.width):
                if x == 0 or y == 0 or x == self.width - 1 or y == self.height - 1:
                    self.grid[y][x] = WALL

        for _ in range(210):
            x = self.rng.randrange(2, self.width - 2)
            y = self.rng.randrange(2, self.height - 2)
            if math.dist((x, y), (6, 6)) > 7:
                self.grid[y][x] = WALL

        for _ in range(18):
            start = (self.rng.randrange(5, self.width - 8), self.rng.randrange(5, self.height - 8))
            length = self.rng.randrange(4, 10)
            horizontal = self.rng.random() > 0.5
            for i in range(length):
                x = start[0] + (i if horizontal else 0)
                y = start[1] + (0 if horizontal else i)
                if self.inside((x, y)) and math.dist((x, y), (6, 6)) > 8:
                    self.grid[y][x] = WALL

        self._carve_paths()
        self._paint((6, 6), 3, SAFE)
        self.grid[6][6] = CHARGER
        self._paint((self.width - 8, self.height - 7), 3, SAFE)
        self.grid[self.height - 7][self.width - 8] = CHARGER
        self._paint((10, self.height - 8), 2, SAFE)

        for _ in range(8):
            center = (self.rng.randrange(10, self.width - 9), self.rng.randrange(8, self.height - 7))
            if math.dist(center, (6, 6)) > 12:
                self._paint(center, self.rng.randrange(2, 5), DANGER)

        for _ in range(7):
            center = (self.rng.randrange(8, self.width - 8), self.rng.randrange(7, self.height - 7))
            self._paint(center, self.rng.randrange(2, 5), self.rng.choice([HOT, COLD, ENERGY_FIELD]))

        for _ in range(70):
            self.spawn_resource()

    def step(self) -> None:
        self.age += 1
        self.day_phase = (self.day_phase + 1.0 / 5200.0) % 1.0
        if self.age % 14 == 0:
            self.spawn_resource()
        if self.age % 155 == 0:
            self.evolve_danger()
        if self.age % 420 == 0:
            self.roll_event()

    def sample(self, cell: Cell) -> Dict[str, float | int | bool | Cell]:
        cell_type = WALL if not self.inside(cell) else self.grid[cell[1]][cell[0]]
        temperature = self.temperature_bias
        if cell_type == HOT:
            temperature += 0.75
        elif cell_type == COLD:
            temperature -= 0.75
        energy = 0.0
        if cell_type == RESOURCE:
            energy = self.resources.get(cell, 0.0)
        elif cell_type == CHARGER:
            energy = 0.8
        elif cell_type == ENERGY_FIELD:
            energy = 0.22
        return {
            "cell": cell,
            "type": cell_type,
            "blocked": cell_type == WALL,
            "danger": 1.0 if cell_type == DANGER else 0.12 if cell_type == ENERGY_FIELD else 0.0,
            "safety": 1.0 if cell_type in (SAFE, CHARGER) else 0.0,
            "energy": energy,
            "resource": cell_type == RESOURCE,
            "charger": cell_type == CHARGER,
            "temperature": temperature,
        }

    def passable(self, cell: Cell) -> bool:
        return self.inside(cell) and self.grid[cell[1]][cell[0]] != WALL

    def inside(self, cell: Cell) -> bool:
        x, y = cell
        return 0 <= x < self.width and 0 <= y < self.height

    def consume(self, cell: Cell, amount: float) -> float:
        if self.sample(cell)["type"] != RESOURCE:
            return 0.0
        stored = self.resources.get(cell, 0.0)
        taken = min(stored, amount)
        stored -= taken
        if stored <= 0.015:
            self.resources.pop(cell, None)
            self.grid[cell[1]][cell[0]] = EMPTY
            self.event_log.append("resource depleted at %s" % (cell,))
        else:
            self.resources[cell] = stored
        self.event_log = self.event_log[-12:]
        return taken

    def spawn_resource(self) -> None:
        if len(self.resources) >= 90:
            return
        for _ in range(70):
            cell = (self.rng.randrange(2, self.width - 2), self.rng.randrange(2, self.height - 2))
            if self.grid[cell[1]][cell[0]] == EMPTY:
                self.grid[cell[1]][cell[0]] = RESOURCE
                self.resources[cell] = self.rng.uniform(0.28, 1.0)
                return

    def evolve_danger(self) -> None:
        additions: List[Cell] = []
        removals: List[Cell] = []
        for y in range(1, self.height - 1):
            for x in range(1, self.width - 1):
                if self.grid[y][x] == DANGER:
                    if self.rng.random() < 0.018:
                        removals.append((x, y))
                    for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                        if self.grid[ny][nx] == EMPTY and self.rng.random() < 0.014:
                            additions.append((nx, ny))
        for cell in additions[:20]:
            if math.dist(cell, (6, 6)) > 9:
                self.grid[cell[1]][cell[0]] = DANGER
        for cell in removals[:10]:
            self.grid[cell[1]][cell[0]] = EMPTY
        self.event_log.append("danger field evolved")
        self.event_log = self.event_log[-12:]

    def roll_event(self) -> None:
        event = self.rng.choice(["clear", "ion wind", "cold drift", "thermal swell"])
        self.weather = event
        self.temperature_bias = {"clear": 0.0, "ion wind": 0.05, "cold drift": -0.24, "thermal swell": 0.29}[event]
        self.event_log.append("weather shift: %s" % event)
        self.event_log = self.event_log[-12:]

    def light(self) -> float:
        wave = math.sin(self.day_phase * math.tau - math.pi * 0.5) * 0.5 + 0.5
        return clamp(0.18 + wave * 0.82)

    def _carve_paths(self) -> None:
        mid_y = self.height // 2
        mid_x = self.width // 2
        for x in range(2, self.width - 2):
            self.grid[mid_y][x] = EMPTY
            if self.rng.random() > 0.66:
                self.grid[min(self.height - 2, max(1, mid_y + self.rng.choice([-1, 0, 1])))][x] = EMPTY
        for y in range(2, self.height - 2):
            self.grid[y][mid_x] = EMPTY
            if self.rng.random() > 0.66:
                self.grid[y][min(self.width - 2, max(1, mid_x + self.rng.choice([-1, 0, 1])))] = EMPTY
        for y in range(2, 13):
            for x in range(2, 15):
                self.grid[y][x] = EMPTY

    def _paint(self, center: Cell, radius: int, cell_type: int) -> None:
        cx, cy = center
        for y in range(cy - radius, cy + radius + 1):
            for x in range(cx - radius, cx + radius + 1):
                if self.inside((x, y)) and math.dist((x, y), center) <= radius:
                    if x in (0, self.width - 1) or y in (0, self.height - 1):
                        continue
                    if self.grid[y][x] != WALL or cell_type == SAFE:
                        self.grid[y][x] = cell_type


@dataclass
class Robot:
    x: float = 6.5
    y: float = 6.5
    heading: float = 0.0
    vx: float = 0.0
    vy: float = 0.0
    energy: float = 0.72
    stress: float = 0.18
    damage: float = 0.0
    confidence: float = 0.14
    curiosity: float = 0.82
    fatigue: float = 0.0
    fear_memory: float = 0.0
    adaptation: float = 0.0
    exploration_rate: float = 0.28
    rng: random.Random = field(default_factory=lambda: random.Random(113))
    memory: Dict[Cell, Dict[str, float]] = field(default_factory=dict)
    q_table: Dict[Tuple[str, str], float] = field(default_factory=dict)
    short_term: List[Dict[str, object]] = field(default_factory=list)
    route: List[Tuple[float, float]] = field(default_factory=list)
    reward_history: List[float] = field(default_factory=list)
    energy_history: List[float] = field(default_factory=list)
    stress_history: List[float] = field(default_factory=list)
    action_scores: Dict[str, float] = field(default_factory=dict)
    sensor_rays: List[Dict[str, object]] = field(default_factory=list)
    context: str = "birth"
    action: str = "wake"
    last_reward: float = 0.0
    collisions: int = 0
    steps: int = 0

    @property
    def cell(self) -> Cell:
        return int(self.x), int(self.y)

    def step(self, world: World) -> None:
        self.steps += 1
        before = self.snapshot_needs()
        scan = self.scan(world)
        current_sample = world.sample(self.cell)
        self.observe(scan, current_sample, world.age)
        self.update_needs(current_sample, world)
        self.context = self.context_bucket(scan)
        self.action = self.decide(scan)
        moved = self.move(world, scan)
        after_sample = world.sample(self.cell)
        self.apply_environment(world, after_sample)
        self.last_reward = self.evaluate(before, after_sample, moved, scan)
        self.learn(self.context, self.action, self.last_reward)
        self.record_history()

    def snapshot_needs(self) -> Dict[str, float]:
        return {
            "energy": self.energy,
            "stress": self.stress,
            "damage": self.damage,
            "confidence": self.confidence,
            "fatigue": self.fatigue,
        }

    def scan(self, world: World) -> Dict[str, object]:
        rays: List[Dict[str, object]] = []
        energy_vector = [0.0, 0.0]
        danger_vector = [0.0, 0.0]
        safe_vector = [0.0, 0.0]
        wall_vector = [0.0, 0.0]
        danger_seen = 0.0
        energy_seen = 0.0
        safe_seen = 0.0
        ray_count = 27
        fov = math.radians(150)
        for i in range(ray_count):
            ratio = i / (ray_count - 1)
            angle = self.heading - fov * 0.5 + ratio * fov
            hit = self.cast_ray(world, angle)
            rays.append(hit)
            dx, dy = math.cos(angle), math.sin(angle)
            closeness = 1.0 - min(1.0, float(hit["distance"]) / 12.0)
            if hit["blocked"]:
                wall_vector[0] -= dx * max(0.15, closeness)
                wall_vector[1] -= dy * max(0.15, closeness)
            if float(hit["danger"]) > 0:
                danger_vector[0] -= dx * (0.45 + closeness)
                danger_vector[1] -= dy * (0.45 + closeness)
                danger_seen = max(danger_seen, float(hit["danger"]) * (0.35 + closeness))
            if float(hit["energy"]) > 0:
                energy_vector[0] += dx * (float(hit["energy"]) + closeness * 0.55)
                energy_vector[1] += dy * (float(hit["energy"]) + closeness * 0.55)
                energy_seen = max(energy_seen, float(hit["energy"]) * (0.35 + closeness))
            if float(hit["safety"]) > 0:
                safe_vector[0] += dx * (float(hit["safety"]) + closeness * 0.35)
                safe_vector[1] += dy * (float(hit["safety"]) + closeness * 0.35)
                safe_seen = max(safe_seen, float(hit["safety"]))

        self.sensor_rays = rays
        return {
            "rays": rays,
            "energy_vector": tuple(energy_vector),
            "danger_vector": tuple(danger_vector),
            "safe_vector": tuple(safe_vector),
            "wall_vector": tuple(wall_vector),
            "danger_seen": danger_seen,
            "energy_seen": energy_seen,
            "safe_seen": safe_seen,
        }

    def cast_ray(self, world: World, angle: float) -> Dict[str, object]:
        distance = 0.0
        dx, dy = math.cos(angle), math.sin(angle)
        last_cell = self.cell
        while distance <= 12.0:
            px = self.x + dx * distance
            py = self.y + dy * distance
            cell = (int(px), int(py))
            last_cell = cell
            sample = world.sample(cell)
            if sample["blocked"] or float(sample["danger"]) > 0 or float(sample["energy"]) > 0 or float(sample["safety"]) > 0:
                return {
                    "start": (self.x, self.y),
                    "end": (px, py),
                    "cell": cell,
                    "distance": distance,
                    "type": sample["type"],
                    "blocked": sample["blocked"],
                    "danger": sample["danger"],
                    "energy": sample["energy"],
                    "safety": sample["safety"],
                }
            distance += 0.28
        return {
            "start": (self.x, self.y),
            "end": (self.x + dx * 12.0, self.y + dy * 12.0),
            "cell": last_cell,
            "distance": 12.0,
            "type": EMPTY,
            "blocked": False,
            "danger": 0.0,
            "energy": 0.0,
            "safety": 0.0,
        }

    def observe(self, scan: Dict[str, object], current_sample: Dict[str, object], world_age: int) -> None:
        self.remember_cell(self.cell, current_sample, 1.0, world_age)
        self.short_term.append(
            {
                "age": world_age,
                "cell": self.cell,
                "type": CELL_NAMES[int(current_sample["type"])],
                "danger": float(current_sample["danger"]),
                "energy": float(current_sample["energy"]),
            }
        )
        for ray in scan["rays"]:
            assert isinstance(ray, dict)
            strength = clamp(1.0 - float(ray["distance"]) / 12.0, 0.08, 0.85)
            self.remember_cell(ray["cell"], ray, strength, world_age)

        self.short_term = self.short_term[-80:]
        self.route.append((self.x, self.y))
        self.route = self.route[-260:]
        if self.steps % 55 == 0:
            self.decay_memory()

    def remember_cell(self, cell: Cell, sample: Dict[str, object], strength: float, world_age: int) -> None:
        if cell[0] < 0 or cell[1] < 0:
            return
        entry = self.memory.setdefault(
            cell,
            {
                "visits": 0.0,
                "familiarity": 0.0,
                "danger": 0.0,
                "energy": 0.0,
                "safety": 0.0,
                "fear": 0.0,
                "confidence": 0.0,
                "last_seen": 0.0,
            },
        )
        entry["visits"] += strength
        entry["familiarity"] = clamp(entry["familiarity"] + 0.018 * strength)
        entry["danger"] = max(entry["danger"] * 0.986, float(sample.get("danger", 0.0)) * strength)
        entry["energy"] = max(entry["energy"] * 0.970, float(sample.get("energy", 0.0)) * strength)
        entry["safety"] = max(entry["safety"] * 0.990, float(sample.get("safety", 0.0)) * strength)
        entry["last_seen"] = float(world_age)
        if float(sample.get("danger", 0.0)) > 0:
            entry["fear"] = clamp(entry["fear"] + float(sample.get("danger", 0.0)) * 0.040 * strength)
        if float(sample.get("energy", 0.0)) > 0 or float(sample.get("safety", 0.0)) > 0:
            entry["confidence"] = clamp(entry["confidence"] + 0.020 * strength)

    def decay_memory(self) -> None:
        removable: List[Cell] = []
        for cell, entry in self.memory.items():
            entry["danger"] *= 0.992
            entry["energy"] *= 0.980
            entry["safety"] *= 0.996
            entry["fear"] *= 0.997
            entry["confidence"] *= 0.999
            if entry["visits"] < 0.25 and entry["familiarity"] < 0.05:
                removable.append(cell)
        for cell in removable:
            self.memory.pop(cell, None)

    def update_needs(self, sample: Dict[str, object], world: World) -> None:
        speed = math.hypot(self.vx, self.vy)
        self.energy = clamp(self.energy - 0.0017 - speed * 0.0018)
        self.fatigue = clamp(self.fatigue + speed * 0.0023 + 0.0008)
        if self.action == "rest":
            self.fatigue = clamp(self.fatigue - 0.018)
            self.stress = clamp(self.stress - 0.006)
        if world.light() < 0.30:
            self.stress = clamp(self.stress + 0.0018)
        temperature = abs(float(sample["temperature"]))
        if temperature > 0.45:
            self.stress = clamp(self.stress + temperature * 0.005)
            self.fatigue = clamp(self.fatigue + temperature * 0.004)
        self.curiosity = clamp(self.curiosity + 0.0015 * self.energy - self.stress * 0.001)
        self.fear_memory = clamp(self.fear_memory * 0.9993)

    def priorities(self) -> Dict[str, float]:
        return {
            "energy": clamp(1.0 - self.energy),
            "safety": clamp(self.stress * 0.65 + self.damage * 0.55 + self.fear_memory * 0.45),
            "recovery": clamp(self.damage * 0.90 + self.fatigue * 0.40 + (1.0 - self.energy) * 0.18),
            "curiosity": clamp(self.curiosity * self.energy * (1.0 - self.stress * 0.60)),
            "stability": clamp(1.0 - self.memory.get(self.cell, {}).get("familiarity", 0.0)),
        }

    def context_bucket(self, scan: Dict[str, object]) -> str:
        return "|".join(
            [
                "low_energy" if self.energy < 0.32 else "energy_ok",
                "hurt" if self.damage > 0.25 else "body_ok",
                "stressed" if self.stress > 0.45 else "calm",
                "danger_seen" if float(scan["danger_seen"]) > 0.22 else "danger_clear",
                "energy_seen" if float(scan["energy_seen"]) > 0.12 else "energy_hidden",
                "tired" if self.fatigue > 0.55 else "mobile",
            ]
        )

    def decide(self, scan: Dict[str, object]) -> str:
        priorities = self.priorities()
        scores = {action: self.q_table.get((self.context, action), 0.0) for action in ACTIONS}
        scores["seek_energy"] += priorities["energy"] * 2.15 + float(scan["energy_seen"]) * 1.30
        scores["avoid_danger"] += priorities["safety"] * 2.20 + float(scan["danger_seen"]) * 2.40
        scores["rest"] += priorities["recovery"] * 1.75 + float(scan["safe_seen"]) * 0.25
        scores["map_unknown"] += priorities["stability"] * 0.95 + priorities["curiosity"] * 0.55
        scores["explore"] += priorities["curiosity"] * 1.25 + self.confidence * 0.35
        scores["return_safe"] += priorities["safety"] * 1.20 + priorities["recovery"] * 0.85

        if self.energy < 0.18:
            scores["seek_energy"] += 1.9
        if self.damage > 0.34:
            scores["return_safe"] += 1.3
            scores["rest"] += 0.8
        if self.rng.random() < self.exploration_rate:
            action = self.rng.choice(ACTIONS)
        else:
            action = max(scores, key=scores.get)
        self.action_scores = scores
        return action

    def move(self, world: World, scan: Dict[str, object]) -> bool:
        if self.action == "rest" and self.energy > 0.24:
            self.vx *= 0.70
            self.vy *= 0.70
            return False

        direction = self.direction_for_action(world, scan)
        danger = scan["danger_vector"]
        wall = scan["wall_vector"]
        assert isinstance(danger, tuple)
        assert isinstance(wall, tuple)
        direction = unit((direction[0] + danger[0] * 0.75 + wall[0] * 0.48, direction[1] + danger[1] * 0.75 + wall[1] * 0.48), self.heading)
        target_heading = math.atan2(direction[1], direction[0])
        angle_diff = math.atan2(math.sin(target_heading - self.heading), math.cos(target_heading - self.heading))
        self.heading += clamp(angle_diff, -0.16, 0.16)

        speed_by_action = {
            "avoid_danger": 0.23,
            "seek_energy": 0.19,
            "return_safe": 0.17,
            "map_unknown": 0.15,
            "explore": 0.16,
            "rest": 0.05,
        }
        speed = speed_by_action.get(self.action, 0.14) * clamp(1.0 - self.fatigue * 0.45, 0.35, 1.0)
        self.vx = self.vx * 0.74 + math.cos(self.heading) * speed * 0.26
        self.vy = self.vy * 0.74 + math.sin(self.heading) * speed * 0.26
        nx = self.x + self.vx
        ny = self.y + self.vy
        old = (self.x, self.y)
        if world.passable((int(nx), int(ny))):
            self.x, self.y = nx, ny
            return math.dist(old, (self.x, self.y)) > 0.01
        if world.passable((int(nx), int(self.y))):
            self.x = nx
            self.vy *= -0.25
            self.collisions += 1
            return True
        if world.passable((int(self.x), int(ny))):
            self.y = ny
            self.vx *= -0.25
            self.collisions += 1
            return True
        self.vx *= -0.20
        self.vy *= -0.20
        self.heading += self.rng.uniform(1.0, 2.2)
        self.stress = clamp(self.stress + 0.018)
        self.collisions += 1
        return False

    def direction_for_action(self, world: World, scan: Dict[str, object]) -> Tuple[float, float]:
        if self.action == "seek_energy":
            vector = scan["energy_vector"]
            assert isinstance(vector, tuple)
            if math.hypot(vector[0], vector[1]) > 0.04:
                return unit(vector, self.heading)
            target = self.best_memory_target("energy")
            if target:
                return unit((target[0] + 0.5 - self.x, target[1] + 0.5 - self.y), self.heading)
        if self.action in ("return_safe", "rest"):
            target = self.best_memory_target("safety") or (6, 6)
            return unit((target[0] + 0.5 - self.x, target[1] + 0.5 - self.y), self.heading)
        if self.action == "avoid_danger":
            vector = scan["danger_vector"]
            assert isinstance(vector, tuple)
            if math.hypot(vector[0], vector[1]) > 0.04:
                return unit(vector, self.heading)
        if self.action == "map_unknown":
            novelty = self.novelty_vector(world)
            if novelty:
                return novelty
        wander = self.rng.uniform(-0.55, 0.55)
        return unit((math.cos(self.heading + wander), math.sin(self.heading + wander)), self.heading)

    def best_memory_target(self, kind: str) -> Cell | None:
        best_cell: Cell | None = None
        best_score = -999.0
        for cell, entry in self.memory.items():
            distance = math.dist(cell, self.cell)
            if distance > 42:
                continue
            value = entry.get(kind, 0.0)
            score = value * 2.0 + entry.get("confidence", 0.0) * 0.3 - entry.get("fear", 0.0) * 0.9 - distance * 0.025
            if kind == "energy":
                score += entry.get("energy", 0.0) * 1.4
            if score > best_score:
                best_score = score
                best_cell = cell
        return best_cell

    def novelty_vector(self, world: World) -> Tuple[float, float] | None:
        best_cell: Cell | None = None
        best_score = -999.0
        cx, cy = self.cell
        for dy in range(-9, 10, 2):
            for dx in range(-9, 10, 2):
                if dx == 0 and dy == 0:
                    continue
                cell = (cx + dx, cy + dy)
                if not world.passable(cell):
                    continue
                entry = self.memory.get(cell, {})
                visits = entry.get("visits", 0.0)
                fear = entry.get("fear", 0.0) + entry.get("danger", 0.0)
                score = 1.0 / (1.0 + visits * 0.35) - fear * 1.6 - math.dist(cell, self.cell) * 0.015
                if score > best_score:
                    best_cell = cell
                    best_score = score
        if not best_cell:
            return None
        return unit((best_cell[0] + 0.5 - self.x, best_cell[1] + 0.5 - self.y), self.heading)

    def apply_environment(self, world: World, sample: Dict[str, object]) -> None:
        if sample["resource"]:
            gained = world.consume(self.cell, 0.035)
            self.energy = clamp(self.energy + gained * 0.72)
            self.confidence = clamp(self.confidence + gained * 0.08)
        elif sample["charger"]:
            self.energy = clamp(self.energy + 0.012)
            self.damage = clamp(self.damage - 0.004)
            self.stress = clamp(self.stress - 0.008)
        elif float(sample["energy"]) > 0:
            self.energy = clamp(self.energy + float(sample["energy"]) * 0.0015)

        if float(sample["danger"]) > 0:
            harm = float(sample["danger"]) * 0.013
            self.damage = clamp(self.damage + harm)
            self.stress = clamp(self.stress + harm * 1.7)
            self.fear_memory = clamp(self.fear_memory + harm * 1.4)
        if abs(float(sample["temperature"])) > 0.55:
            self.damage = clamp(self.damage + abs(float(sample["temperature"])) * 0.0018)
        if float(sample["safety"]) > 0:
            self.damage = clamp(self.damage - 0.0018)
            self.stress = clamp(self.stress - 0.006)

    def evaluate(self, before: Dict[str, float], sample: Dict[str, object], moved: bool, scan: Dict[str, object]) -> float:
        reward = 0.0
        reward += (self.energy - before["energy"]) * 2.2
        reward += (before["damage"] - self.damage) * 2.0
        reward += (before["stress"] - self.stress) * 1.2
        reward += 0.006 if moved else -0.006
        reward -= float(sample["danger"]) * 0.35
        if sample["resource"] or sample["charger"]:
            reward += 0.12
        if self.action == "avoid_danger" and float(scan["danger_seen"]) > 0:
            reward += 0.035
        if self.action in ("explore", "map_unknown"):
            reward += (1.0 - self.memory.get(self.cell, {}).get("familiarity", 0.0)) * 0.020
        return clamp(reward, -1.0, 1.0)

    def learn(self, context: str, action: str, reward: float) -> None:
        old_value = self.q_table.get((context, action), 0.0)
        best_next = max((self.q_table.get((context, candidate), 0.0) for candidate in ACTIONS), default=0.0)
        updated = old_value + 0.13 * (reward + 0.72 * best_next - old_value)
        self.q_table[(context, action)] = max(-3.0, min(3.0, updated))
        self.adaptation = clamp(self.adaptation + abs(reward) * 0.002 + 0.0002)
        self.confidence = clamp(self.confidence + reward * 0.014)
        self.reward_history.append(reward)
        self.reward_history = self.reward_history[-180:]
        recent = sum(self.reward_history[-50:]) / max(1, len(self.reward_history[-50:]))
        if recent > 0.01:
            self.exploration_rate = max(0.05, self.exploration_rate * 0.998)
        else:
            self.exploration_rate = min(0.44, self.exploration_rate + 0.0007)

    def record_history(self) -> None:
        self.energy_history.append(self.energy)
        self.stress_history.append(self.stress)
        self.energy_history = self.energy_history[-220:]
        self.stress_history = self.stress_history[-220:]


class LiveObserver:
    def __init__(self, seed: int, speed: int) -> None:
        self.seed = seed
        self.world = World(seed=seed)
        self.robot = Robot(rng=random.Random(seed + 101))
        self.speed = max(1, min(24, speed))
        self.paused = False
        self.show_memory = True
        self.show_sensors = True
        self.root = tk.Tk()
        self.root.title("Digital Robot ALife - Live Observer")
        self.root.geometry("1280x760")
        self.root.minsize(1080, 680)
        self.canvas = tk.Canvas(self.root, bg="#01040a", highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        self.root.bind("<space>", self.toggle_pause)
        self.root.bind("<Up>", self.increase_speed)
        self.root.bind("<Down>", self.decrease_speed)
        self.root.bind("r", self.reset)
        self.root.bind("R", self.reset)
        self.root.bind("m", self.toggle_memory)
        self.root.bind("M", self.toggle_memory)
        self.root.bind("s", self.toggle_sensors)
        self.root.bind("S", self.toggle_sensors)
        self.tick()

    def run(self) -> None:
        self.root.mainloop()

    def tick(self) -> None:
        if not self.paused:
            for _ in range(self.speed):
                self.world.step()
                self.robot.step(self.world)
        self.draw()
        self.root.after(33, self.tick)

    def draw(self) -> None:
        self.canvas.delete("all")
        width = max(1, self.canvas.winfo_width())
        height = max(1, self.canvas.winfo_height())
        map_left = 18
        map_top = 18
        map_width = min(width - 430, int((height - 80) * 1.55))
        cell_size = max(8, min(map_width // self.world.width, (height - 124) // self.world.height))
        map_width = cell_size * self.world.width
        map_height = cell_size * self.world.height
        panel_left = map_left + map_width + 22

        self.canvas.create_rectangle(0, 0, width, height, fill="#01040a", outline="")
        self.draw_world(map_left, map_top, cell_size)
        self.draw_robot(map_left, map_top, cell_size)
        self.draw_dashboard(panel_left, 18, width - panel_left - 18, height - 36)
        self.draw_bottom_timeline(map_left, map_top + map_height + 16, map_width, height - (map_top + map_height + 28))

    def draw_world(self, left: int, top: int, size: int) -> None:
        light = self.world.light()
        for y in range(self.world.height):
            for x in range(self.world.width):
                cell_type = self.world.grid[y][x]
                base = CELL_COLORS[cell_type]
                color = blend_hex("#020710", base, 0.55 + light * 0.45)
                x0, y0 = left + x * size, top + y * size
                self.canvas.create_rectangle(x0, y0, x0 + size, y0 + size, fill=color, outline="#0b1a27")

        if self.show_memory:
            for (x, y), entry in self.robot.memory.items():
                if not self.world.inside((x, y)):
                    continue
                x0, y0 = left + x * size, top + y * size
                fear = entry.get("fear", 0.0) + entry.get("danger", 0.0)
                confidence = entry.get("confidence", 0.0) + entry.get("safety", 0.0) + entry.get("energy", 0.0)
                familiarity = entry.get("familiarity", 0.0)
                if fear > confidence:
                    color = blend_hex("#ff405e", "#4b101a", clamp(fear))
                else:
                    color = blend_hex("#41e0c0", "#0f2f37", clamp(confidence + familiarity * 0.3))
                pad = max(1, size // 4)
                self.canvas.create_rectangle(x0 + pad, y0 + pad, x0 + size - pad, y0 + size - pad, outline=color)

        if len(self.robot.route) > 1:
            points: List[float] = []
            for x, y in self.robot.route[-130:]:
                points.extend([left + x * size, top + y * size])
            if len(points) >= 4:
                self.canvas.create_line(*points, fill="#8ccde6", width=1, smooth=True)

        self.canvas.create_rectangle(left, top, left + self.world.width * size, top + self.world.height * size, outline="#78a8bf", width=2)

    def draw_robot(self, left: int, top: int, size: int) -> None:
        rx = left + self.robot.x * size
        ry = top + self.robot.y * size

        if self.show_sensors:
            for ray in self.robot.sensor_rays:
                end = ray["end"]
                assert isinstance(end, tuple)
                color = "#3e7188"
                if float(ray["danger"]) > 0:
                    color = "#ff526a"
                elif float(ray["energy"]) > 0:
                    color = "#75f0bd"
                elif ray["blocked"]:
                    color = "#9cabb8"
                self.canvas.create_line(rx, ry, left + end[0] * size, top + end[1] * size, fill=color)

        radius = max(6, int(size * 0.62))
        core = blend_hex("#27495c", "#74e0ff", self.robot.energy)
        core = blend_hex(core, "#ff4d62", self.robot.stress * 0.55 + self.robot.damage * 0.75)
        self.canvas.create_oval(rx - radius - 3, ry - radius - 1, rx + radius + 3, ry + radius + 5, fill="#000000", outline="")
        self.canvas.create_oval(rx - radius, ry - radius, rx + radius, ry + radius, fill="#0b1823", outline="#9cc7d6", width=2)
        self.canvas.create_oval(rx - radius * 0.52, ry - radius * 0.52, rx + radius * 0.52, ry + radius * 0.52, fill=core, outline="")
        nose_len = radius + 8
        hx = math.cos(self.robot.heading)
        hy = math.sin(self.robot.heading)
        left_wing = self.robot.heading + 2.35
        right_wing = self.robot.heading - 2.35
        points = [
            rx + hx * nose_len,
            ry + hy * nose_len,
            rx + math.cos(left_wing) * radius * 0.75,
            ry + math.sin(left_wing) * radius * 0.75,
            rx + math.cos(right_wing) * radius * 0.75,
            ry + math.sin(right_wing) * radius * 0.75,
        ]
        self.canvas.create_polygon(points, fill="#bcefff", outline="#e8fbff")
        pulse = 2 + int(abs(math.sin(self.robot.steps * 0.08)) * 5)
        self.canvas.create_oval(rx - radius - pulse, ry - radius - pulse, rx + radius + pulse, ry + radius + pulse, outline="#4fcbe8")

    def draw_dashboard(self, left: int, top: int, width: int, height: int) -> None:
        self.canvas.create_rectangle(left, top, left + width, top + height, fill="#040b13", outline="#426173")
        x = left + 18
        y = top + 26
        self.text(x, y, "DIGITAL ORGANISM LIVE OBSERVER", "#9ee3f0", 13, "bold")
        y += 25
        status = "paused" if self.paused else "running"
        self.text(x, y, "state: %s   speed: %dx   step: %d" % (status, self.speed, self.robot.steps), "#d8edf4")
        y += 20
        self.text(x, y, "action: %s" % self.robot.action, "#ffffff", 13, "bold")
        y += 20
        self.text(x, y, "context: %s" % self.robot.context, "#9db9c7", 9)
        y += 24

        bars = [
            ("energy", self.robot.energy, "#62e0a8"),
            ("stress", self.robot.stress, "#e77864"),
            ("damage", self.robot.damage, "#ff4d62"),
            ("fatigue", self.robot.fatigue, "#d0aa58"),
            ("curiosity", self.robot.curiosity, "#8ca5ff"),
            ("confidence", self.robot.confidence, "#6dd6f2"),
            ("fear memory", self.robot.fear_memory, "#d85b7c"),
            ("adaptation", self.robot.adaptation, "#d7c574"),
        ]
        for label, value, color in bars:
            self.bar(x, y, width - 44, label, value, color)
            y += 22

        y += 10
        self.text(x, y, "DECISION PRESSURE", "#9ee3f0", 12, "bold")
        y += 18
        if self.robot.action_scores:
            lowest = min(self.robot.action_scores.values())
            highest = max(self.robot.action_scores.values())
            span = max(0.1, highest - lowest)
            for action in ACTIONS:
                raw = self.robot.action_scores.get(action, 0.0)
                scaled = (raw - lowest) / span
                color = "#78d9ef" if action == self.robot.action else "#4b7789"
                self.bar(x, y, width - 44, action, scaled, color, value_text="%.2f" % raw)
                y += 19

        y += 12
        self.text(x, y, "WORLD + MEMORY", "#9ee3f0", 12, "bold")
        y += 19
        lines = [
            "weather: %s   light: %.2f" % (self.world.weather, self.world.light()),
            "resources: %d   known cells: %d" % (len(self.world.resources), len(self.robot.memory)),
            "q entries: %d   collisions: %d" % (len(self.robot.q_table), self.robot.collisions),
            "last reward: %.3f   explore rate: %.2f" % (self.robot.last_reward, self.robot.exploration_rate),
        ]
        for line in lines:
            self.text(x, y, line, "#c4d8df", 10)
            y += 17

        y += 10
        self.text(x, y, "EVENT STREAM", "#9ee3f0", 12, "bold")
        y += 18
        for event in self.world.event_log[-9:]:
            self.text(x, y, event, "#aebfc7", 9)
            y += 15

        controls = "Space pause | Up/Down speed | R reset | M memory | S sensors"
        self.text(x, top + height - 16, controls, "#6f93a3", 9)

    def draw_bottom_timeline(self, left: int, top: int, width: int, height: int) -> None:
        if height < 46:
            return
        self.canvas.create_rectangle(left, top, left + width, top + height, fill="#030912", outline="#264252")
        self.text(left + 12, top + 18, "life traces: energy / stress / reward", "#85bdcc", 10, "bold")
        plot_left = left + 190
        plot_top = top + 12
        plot_width = max(100, width - 210)
        plot_height = max(28, height - 24)
        self.sparkline(self.robot.energy_history, plot_left, plot_top, plot_width, plot_height, "#62e0a8", 0.0, 1.0)
        self.sparkline(self.robot.stress_history, plot_left, plot_top, plot_width, plot_height, "#e77864", 0.0, 1.0)
        reward_values = [(value + 1.0) * 0.5 for value in self.robot.reward_history]
        self.sparkline(reward_values, plot_left, plot_top, plot_width, plot_height, "#d7c574", 0.0, 1.0)

    def sparkline(self, values: List[float], left: int, top: int, width: int, height: int, color: str, low: float, high: float) -> None:
        if len(values) < 2:
            return
        span = max(0.0001, high - low)
        points: List[float] = []
        visible = values[-220:]
        for index, value in enumerate(visible):
            x = left + index * width / max(1, len(visible) - 1)
            y = top + height - clamp((value - low) / span) * height
            points.extend([x, y])
        self.canvas.create_line(*points, fill=color, width=2, smooth=True)

    def bar(self, x: int, y: int, width: int, label: str, value: float, color: str, value_text: str | None = None) -> None:
        value = clamp(value)
        self.text(x, y + 12, label, "#b7cbd2", 9)
        bx = x + 102
        bw = max(70, width - 154)
        self.canvas.create_rectangle(bx, y + 3, bx + bw, y + 13, fill="#132434", outline="#284758")
        self.canvas.create_rectangle(bx, y + 3, bx + bw * value, y + 13, fill=color, outline="")
        shown = value_text if value_text is not None else "%.2f" % value
        self.text(bx + bw + 8, y + 12, shown, "#d7e7ed", 9)

    def text(self, x: int, y: int, text: str, fill: str, size: int = 10, weight: str = "normal") -> None:
        self.canvas.create_text(x, y, text=text, fill=fill, anchor="w", font=("Consolas", size, weight))

    def toggle_pause(self, _event: object = None) -> None:
        self.paused = not self.paused

    def increase_speed(self, _event: object = None) -> None:
        self.speed = min(24, self.speed + 1)

    def decrease_speed(self, _event: object = None) -> None:
        self.speed = max(1, self.speed - 1)

    def toggle_memory(self, _event: object = None) -> None:
        self.show_memory = not self.show_memory

    def toggle_sensors(self, _event: object = None) -> None:
        self.show_sensors = not self.show_sensors

    def reset(self, _event: object = None) -> None:
        self.seed += 1
        self.world = World(seed=self.seed)
        self.robot = Robot(rng=random.Random(self.seed + 101))


def run_headless_test(steps: int, seed: int) -> Dict[str, object]:
    world = World(seed=seed)
    robot = Robot(rng=random.Random(seed + 101))
    for _ in range(steps):
        world.step()
        robot.step(world)
        assert world.passable(robot.cell), "robot entered wall"
        assert 0.0 <= robot.energy <= 1.0
        assert 0.0 <= robot.stress <= 1.0
        assert 0.0 <= robot.damage <= 1.0
        assert len(robot.sensor_rays) > 0
    return {
        "status": "ok",
        "steps": steps,
        "seed": seed,
        "position": [round(robot.x, 2), round(robot.y, 2)],
        "action": robot.action,
        "context": robot.context,
        "energy": round(robot.energy, 4),
        "stress": round(robot.stress, 4),
        "damage": round(robot.damage, 4),
        "fatigue": round(robot.fatigue, 4),
        "memory_cells": len(robot.memory),
        "q_entries": len(robot.q_table),
        "resources": len(world.resources),
        "collisions": robot.collisions,
        "last_reward": round(robot.last_reward, 4),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the all-in-one animated artificial life observer.")
    parser.add_argument("--seed", type=int, default=19)
    parser.add_argument("--speed", type=int, default=4)
    parser.add_argument("--headless-test", action="store_true")
    parser.add_argument("--steps", type=int, default=900)
    args = parser.parse_args()

    if args.headless_test:
        print(json.dumps(run_headless_test(args.steps, args.seed), indent=2))
        return

    LiveObserver(seed=args.seed, speed=args.speed).run()


if __name__ == "__main__":
    main()
