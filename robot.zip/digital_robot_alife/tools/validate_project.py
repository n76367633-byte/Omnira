from __future__ import annotations

import json
from pathlib import Path

from headless_life_sim import run_simulation


ROOT = Path(__file__).resolve().parents[1]

REQUIRED_FILES = [
    "project.godot",
    "scenes/main.tscn",
    "scripts/main.gd",
    "scripts/world/world_simulation.gd",
    "scripts/robot/digital_robot.gd",
    "scripts/robot/needs_component.gd",
    "scripts/robot/sensors_component.gd",
    "scripts/robot/memory_component.gd",
    "scripts/robot/learning_component.gd",
    "scripts/robot/brain_component.gd",
    "scripts/robot/motion_component.gd",
    "scripts/ui/simulation_hud.gd",
    "tools/live_alife_observer.py",
]


def check_required_files() -> None:
    missing = [path for path in REQUIRED_FILES if not (ROOT / path).exists()]
    if missing:
        raise AssertionError(f"Missing required files: {missing}")


def check_godot_project() -> None:
    project = (ROOT / "project.godot").read_text(encoding="utf-8")
    if 'run/main_scene="res://scenes/main.tscn"' not in project:
        raise AssertionError("project.godot does not point at the main scene")


def check_balanced_scripts() -> None:
    pairs = {"(": ")", "[": "]", "{": "}"}
    closers = {")": "(", "]": "[", "}": "{"}
    for script in (ROOT / "scripts").rglob("*.gd"):
        stack: list[str] = []
        text = script.read_text(encoding="utf-8")
        for line_number, line in enumerate(text.splitlines(), start=1):
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            for char in stripped:
                if char in pairs:
                    stack.append(char)
                elif char in closers:
                    if not stack or stack[-1] != closers[char]:
                        raise AssertionError(f"Unbalanced {char!r} in {script} line {line_number}")
                    stack.pop()
        if stack:
            raise AssertionError(f"Unclosed delimiters in {script}: {stack}")


def check_headless_behavior() -> dict[str, object]:
    summary = run_simulation(steps=700, seed=11)
    if summary["memory_cells"] < 20:
        raise AssertionError("Robot did not form enough spatial memories")
    if summary["q_entries"] < 3:
        raise AssertionError("Robot did not update enough learning entries")
    if summary["energy"] <= 0:
        raise AssertionError("Robot fully depleted energy during validation")
    return summary


def main() -> None:
    check_required_files()
    check_godot_project()
    check_balanced_scripts()
    summary = check_headless_behavior()
    print(json.dumps({"status": "ok", "headless_summary": summary}, indent=2))


if __name__ == "__main__":
    main()
