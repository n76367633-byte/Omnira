from __future__ import annotations

import json
import math
import random
from dataclasses import dataclass, field
from typing import Dict, List, Tuple


EMPTY = 0
WALL = 1
DANGER = 2
SAFE = 3
RESOURCE = 4
CHARGER = 5
HOT = 6
COLD = 7
ENERGY_FIELD = 8


Cell = Tuple[int, int]


@dataclass
class World:
    width: int = 42
    height: int = 28
    seed: int = 7
    grid: List[List[int]] = field(default_factory=list)
    resources: Dict[Cell, float] = field(default_factory=dict)
    age: int = 0

    def __post_init__(self) -> None:
        self.rng = random.Random(self.seed)
        self.generate()

    def generate(self) -> None:
        self.grid = [[EMPTY for _ in range(self.width)] for _ in range(self.height)]
        self.resources.clear()
        for y in range(self.height):
            for x in range(self.width):
                if x == 0 or y == 0 or x == self.width - 1 or y == self.height - 1:
                    self.grid[y][x] = WALL

        for _ in range(95):
            x = self.rng.randrange(2, self.width - 2)
            y = self.rng.randrange(2, self.height - 2)
            if math.dist((x, y), (4, 4)) > 5:
                self.grid[y][x] = WALL

        self._paint((4, 4), 2, SAFE)
        self.grid[4][4] = CHARGER
        self._paint((self.width - 6, self.height - 5), 2, SAFE)
        self.grid[self.height - 5][self.width - 6] = CHARGER

        for _ in range(5):
            center = (self.rng.randrange(8, self.width - 6), self.rng.randrange(7, self.height - 6))
            self._paint(center, self.rng.randrange(2, 4), DANGER)

        for _ in range(3):
            center = (self.rng.randrange(7, self.width - 7), self.rng.randrange(6, self.height - 6))
            self._paint(center, self.rng.randrange(2, 4), self.rng.choice([HOT, COLD, ENERGY_FIELD]))

        for _ in range(36):
            self.spawn_resource()

    def step(self) -> None:
        self.age += 1
        if self.age % 8 == 0:
            self.spawn_resource()
        if self.age % 75 == 0:
            self._evolve_danger()

    def sample(self, cell: Cell) -> Dict[str, float | int | bool | Cell]:
        x, y = cell
        cell_type = WALL if not self.inside(cell) else self.grid[y][x]
        return {
            "cell": cell,
            "type": cell_type,
            "blocked": cell_type == WALL,
            "danger": 1.0 if cell_type == DANGER else 0.0,
            "safety": 1.0 if cell_type in (SAFE, CHARGER) else 0.0,
            "energy": self.resources.get(cell, 0.0) if cell_type == RESOURCE else (0.8 if cell_type == CHARGER else 0.2 if cell_type == ENERGY_FIELD else 0.0),
            "resource": cell_type == RESOURCE,
            "charger": cell_type == CHARGER,
            "temperature": 0.7 if cell_type == HOT else -0.7 if cell_type == COLD else 0.0,
        }

    def consume(self, cell: Cell, amount: float) -> float:
        if self.sample(cell)["type"] != RESOURCE:
            return 0.0
        stored = self.resources.get(cell, 0.0)
        taken = min(stored, amount)
        stored -= taken
        if stored <= 0.01:
            self.resources.pop(cell, None)
            self.grid[cell[1]][cell[0]] = EMPTY
        else:
            self.resources[cell] = stored
        return taken

    def spawn_resource(self) -> None:
        if len(self.resources) >= 46:
            return
        for _ in range(80):
            cell = (self.rng.randrange(2, self.width - 2), self.rng.randrange(2, self.height - 2))
            if self.sample(cell)["type"] == EMPTY:
                self.grid[cell[1]][cell[0]] = RESOURCE
                self.resources[cell] = self.rng.uniform(0.35, 1.0)
                return

    def inside(self, cell: Cell) -> bool:
        x, y = cell
        return 0 <= x < self.width and 0 <= y < self.height

    def passable(self, cell: Cell) -> bool:
        return self.inside(cell) and self.grid[cell[1]][cell[0]] != WALL

    def _paint(self, center: Cell, radius: int, cell_type: int) -> None:
        cx, cy = center
        for y in range(cy - radius, cy + radius + 1):
            for x in range(cx - radius, cx + radius + 1):
                if self.inside((x, y)) and math.dist((x, y), center) <= radius and self.grid[y][x] != WALL:
                    self.grid[y][x] = cell_type

    def _evolve_danger(self) -> None:
        additions: List[Cell] = []
        for y in range(1, self.height - 1):
            for x in range(1, self.width - 1):
                if self.grid[y][x] == DANGER:
                    for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                        if self.grid[ny][nx] == EMPTY and self.rng.random() < 0.035:
                            additions.append((nx, ny))
        for cell in additions[:8]:
            if math.dist(cell, (4, 4)) > 5:
                self.grid[cell[1]][cell[0]] = DANGER


@dataclass
class Robot:
    x: int = 4
    y: int = 4
    energy: float = 0.72
    stress: float = 0.12
    damage: float = 0.0
    curiosity: float = 0.82
    confidence: float = 0.12
    memory: Dict[Cell, Dict[str, float]] = field(default_factory=dict)
    q_table: Dict[Tuple[str, str], float] = field(default_factory=dict)
    rng: random.Random = field(default_factory=lambda: random.Random(13))
    action: str = "wake"
    collisions: int = 0
    reward_sum: float = 0.0

    def step(self, world: World) -> None:
        before = (self.energy, self.stress, self.damage)
        scan = self.scan(world)
        sample = world.sample((self.x, self.y))
        self.remember(sample, 1.0)
        action = self.decide(scan)
        self.action = action
        moved = self.move(world, action, scan)
        after_move = world.sample((self.x, self.y))
        self.apply_consequence(world, after_move)
        self.energy = max(0.0, self.energy - 0.006 - (0.002 if moved else 0.0))
        reward = self.evaluate(before, after_move, moved)
        self.learn(action, scan["context"], reward)
        self.reward_sum += reward
        self.confidence = min(1.0, max(0.0, self.confidence + reward * 0.01))

    def scan(self, world: World) -> Dict[str, object]:
        danger_vector = [0, 0]
        energy_vector = [0, 0]
        danger_seen = 0.0
        energy_seen = 0.0
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, -1), (-1, 1), (1, 1)]
        for dx, dy in directions:
            for distance in range(1, 9):
                cell = (self.x + dx * distance, self.y + dy * distance)
                sample = world.sample(cell)
                if sample["blocked"]:
                    break
                if float(sample["danger"]) > 0:
                    danger_vector[0] -= dx
                    danger_vector[1] -= dy
                    danger_seen = max(danger_seen, 1.0 / distance)
                    break
                if float(sample["energy"]) > 0:
                    energy_vector[0] += dx
                    energy_vector[1] += dy
                    energy_seen = max(energy_seen, float(sample["energy"]) / distance)
                    break
        context = "|".join(
            [
                "low_energy" if self.energy < 0.32 else "energy_ok",
                "hurt" if self.damage > 0.25 else "body_ok",
                "stressed" if self.stress > 0.45 else "calm",
                "danger_seen" if danger_seen > 0.18 else "danger_clear",
                "energy_seen" if energy_seen > 0.08 else "energy_hidden",
            ]
        )
        return {
            "danger_vector": tuple(danger_vector),
            "energy_vector": tuple(energy_vector),
            "danger_seen": danger_seen,
            "energy_seen": energy_seen,
            "context": context,
        }

    def decide(self, scan: Dict[str, object]) -> str:
        actions = ["explore", "seek_energy", "avoid_danger", "rest", "return_safe"]
        context = str(scan["context"])
        scores = {action: self.q_table.get((context, action), 0.0) for action in actions}
        scores["seek_energy"] += (1.0 - self.energy) * 2.0 + float(scan["energy_seen"]) * 1.2
        scores["avoid_danger"] += self.stress * 1.5 + self.damage * 1.0 + float(scan["danger_seen"]) * 2.4
        scores["rest"] += self.damage * 1.5 + (1.0 - self.energy) * 0.4
        scores["explore"] += self.curiosity * self.energy * 0.8
        scores["return_safe"] += self.damage * 1.0 + self.stress * 0.6
        if self.rng.random() < 0.18:
            return self.rng.choice(actions)
        return max(scores, key=scores.get)

    def move(self, world: World, action: str, scan: Dict[str, object]) -> bool:
        if action == "rest":
            return False
        if action == "seek_energy" and scan["energy_vector"] != (0, 0):
            vector = scan["energy_vector"]
        elif action == "avoid_danger" and scan["danger_vector"] != (0, 0):
            vector = scan["danger_vector"]
        elif action == "return_safe":
            vector = (4 - self.x, 4 - self.y)
        else:
            vector = self.rng.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        dx = 0 if vector[0] == 0 else int(math.copysign(1, vector[0]))
        dy = 0 if vector[1] == 0 else int(math.copysign(1, vector[1]))
        target = (self.x + dx, self.y + dy)
        if world.passable(target):
            self.x, self.y = target
            return True
        self.collisions += 1
        return False

    def apply_consequence(self, world: World, sample: Dict[str, float | int | bool | Cell]) -> None:
        if sample["resource"]:
            self.energy = min(1.0, self.energy + world.consume((self.x, self.y), 0.25) * 0.7)
        elif sample["charger"]:
            self.energy = min(1.0, self.energy + 0.08)
            self.damage = max(0.0, self.damage - 0.02)
        if float(sample["danger"]) > 0:
            self.damage = min(1.0, self.damage + 0.06)
            self.stress = min(1.0, self.stress + 0.12)
        if float(sample["safety"]) > 0:
            self.stress = max(0.0, self.stress - 0.04)
        if abs(float(sample["temperature"])) > 0.5:
            self.stress = min(1.0, self.stress + 0.025)

    def evaluate(self, before: Tuple[float, float, float], sample: Dict[str, object], moved: bool) -> float:
        old_energy, old_stress, old_damage = before
        reward = (self.energy - old_energy) * 2.0 + (old_damage - self.damage) * 1.8 + (old_stress - self.stress)
        reward += 0.01 if moved else -0.01
        reward -= 0.35 * float(sample["danger"])
        reward += 0.15 if sample["resource"] or sample["charger"] else 0.0
        return max(-1.0, min(1.0, reward))

    def learn(self, action: str, context: str, reward: float) -> None:
        key = (context, action)
        old = self.q_table.get(key, 0.0)
        self.q_table[key] = max(-3.0, min(3.0, old + 0.15 * (reward - old)))

    def remember(self, sample: Dict[str, object], intensity: float) -> None:
        cell = sample["cell"]
        assert isinstance(cell, tuple)
        entry = self.memory.setdefault(cell, {"visits": 0.0, "danger": 0.0, "energy": 0.0, "safety": 0.0})
        entry["visits"] += intensity
        entry["danger"] = max(entry["danger"] * 0.98, float(sample["danger"]))
        entry["energy"] = max(entry["energy"] * 0.96, float(sample["energy"]))
        entry["safety"] = max(entry["safety"] * 0.98, float(sample["safety"]))


def run_simulation(steps: int = 500, seed: int = 7) -> Dict[str, object]:
    world = World(seed=seed)
    robot = Robot(rng=random.Random(seed + 91))
    for _ in range(steps):
        world.step()
        robot.step(world)
        assert world.passable((robot.x, robot.y)), "robot entered an impassable cell"
        assert 0.0 <= robot.energy <= 1.0, "energy out of range"
        assert 0.0 <= robot.damage <= 1.0, "damage out of range"
        assert 0.0 <= robot.stress <= 1.0, "stress out of range"
    return {
        "steps": steps,
        "seed": seed,
        "position": [robot.x, robot.y],
        "energy": round(robot.energy, 4),
        "stress": round(robot.stress, 4),
        "damage": round(robot.damage, 4),
        "memory_cells": len(robot.memory),
        "q_entries": len(robot.q_table),
        "resources_remaining": len(world.resources),
        "collisions": robot.collisions,
        "reward_sum": round(robot.reward_sum, 4),
        "last_action": robot.action,
    }


def main() -> None:
    print(json.dumps(run_simulation(), indent=2))


if __name__ == "__main__":
    main()
