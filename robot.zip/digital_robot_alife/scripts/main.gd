extends Node2D

const WorldSimulationScript := preload("res://scripts/world/world_simulation.gd")
const DigitalRobotScript := preload("res://scripts/robot/digital_robot.gd")
const SimulationHUDScript := preload("res://scripts/ui/simulation_hud.gd")

const SAVE_PATH := "user://organism_state.json"
const FIXED_STEP := 0.05

var world
var robot
var hud
var camera: Camera2D
var accumulator := 0.0
var simulation_speed := 1.0
var paused := false
var autosave_timer := 0.0


func _ready() -> void:
	randomize()
	RenderingServer.set_default_clear_color(Color8(1, 4, 10))

	world = WorldSimulationScript.new()
	add_child(world)
	world.generate()

	robot = DigitalRobotScript.new()
	add_child(robot)
	robot.configure(world)

	camera = Camera2D.new()
	camera.enabled = true
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 4.0
	camera.zoom = Vector2(0.82, 0.82)
	add_child(camera)

	var hud_layer := CanvasLayer.new()
	add_child(hud_layer)
	hud = SimulationHUDScript.new()
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud_layer.add_child(hud)

	load_state()


func _process(delta: float) -> void:
	if paused:
		_update_camera(delta)
		_update_hud()
		return

	var scaled_delta := clamp(delta * simulation_speed, 0.0, 0.25)
	accumulator += scaled_delta
	while accumulator >= FIXED_STEP:
		world.step(FIXED_STEP)
		robot.step(FIXED_STEP)
		accumulator -= FIXED_STEP

	autosave_timer += delta
	if autosave_timer >= 8.0:
		autosave_timer = 0.0
		save_state()

	_update_camera(delta)
	_update_hud()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_state()


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_SPACE:
			paused = not paused
		elif event.keycode == KEY_EQUAL or event.keycode == KEY_KP_ADD:
			simulation_speed = clamp(simulation_speed + 0.25, 0.25, 4.0)
		elif event.keycode == KEY_MINUS or event.keycode == KEY_KP_SUBTRACT:
			simulation_speed = clamp(simulation_speed - 0.25, 0.25, 4.0)
		elif event.keycode == KEY_R:
			world.generate()
			robot.configure(world)
		elif event.keycode == KEY_F5:
			save_state()
		elif event.keycode == KEY_F9:
			load_state()


func _update_camera(delta: float) -> void:
	if robot == null:
		return
	camera.global_position = camera.global_position.lerp(robot.global_position, clamp(delta * 3.0, 0.0, 1.0))


func _update_hud() -> void:
	if hud == null:
		return
	hud.set_status(robot.snapshot(), world.snapshot(), paused, simulation_speed)


func save_state() -> void:
	if robot == null or world == null:
		return
	var data := {
		"version": 1,
		"saved_unix": Time.get_unix_time_from_system(),
		"world": world.serialize_state(),
		"robot": robot.serialize_state()
	}
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify(data))


func load_state() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	if parsed.has("world"):
		world.deserialize_state(parsed["world"])
	if parsed.has("robot"):
		robot.deserialize_state(parsed["robot"])
