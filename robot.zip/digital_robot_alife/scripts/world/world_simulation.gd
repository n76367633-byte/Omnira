class_name WorldSimulation
extends Node2D

signal world_event(event_name: String, payload: Dictionary)

const CELL_SIZE := 18
const WORLD_SIZE := Vector2i(80, 48)
const MAX_RESOURCES := 80
const DANGER_EVOLVE_INTERVAL := 11.0
const RESOURCE_SPAWN_INTERVAL := 2.5

enum Cell {
	EMPTY,
	WALL,
	DANGER,
	SAFE,
	RESOURCE,
	CHARGER,
	HOT,
	COLD,
	ENERGY_FIELD
}

var rng := RandomNumberGenerator.new()
var grid: Array = []
var resource_energy: Dictionary = {}
var safe_cells: Array = []
var charger_cells: Array = []
var age := 0.0
var day_phase := 0.20
var weather := "clear"
var temperature_bias := 0.0
var resource_timer := 0.0
var danger_timer := 0.0
var event_timer := 0.0
var last_seed := 0


func generate(seed_value: int = 0) -> void:
	last_seed = seed_value
	if last_seed == 0:
		last_seed = int(Time.get_unix_time_from_system()) & 0x7fffffff
	rng.seed = last_seed
	age = 0.0
	day_phase = rng.randf()
	weather = "clear"
	temperature_bias = 0.0
	resource_timer = 0.0
	danger_timer = 0.0
	event_timer = 0.0
	resource_energy.clear()
	safe_cells.clear()
	charger_cells.clear()
	_build_base_grid()
	_add_structural_obstacles()
	_carve_primary_paths()
	_add_safe_and_charge_zones()
	_add_thermal_fields()
	_add_danger_regions()
	_spawn_initial_resources()
	queue_redraw()


func step(delta: float) -> void:
	age += delta
	day_phase = wrapf(day_phase + delta / 240.0, 0.0, 1.0)
	resource_timer += delta
	danger_timer += delta
	event_timer += delta

	if resource_timer >= RESOURCE_SPAWN_INTERVAL:
		resource_timer = 0.0
		_try_spawn_resource()

	if danger_timer >= DANGER_EVOLVE_INTERVAL:
		danger_timer = 0.0
		_evolve_danger()

	if event_timer >= 32.0:
		event_timer = 0.0
		_roll_environment_event()

	queue_redraw()


func snapshot() -> Dictionary:
	return {
		"age": age,
		"day_phase": day_phase,
		"light": get_light_level(),
		"weather": weather,
		"temperature_bias": temperature_bias,
		"resource_count": resource_energy.size(),
		"seed": last_seed
	}


func serialize_state() -> Dictionary:
	var rows := []
	for row in grid:
		rows.append(row.duplicate())
	return {
		"seed": last_seed,
		"grid": rows,
		"resource_energy": resource_energy.duplicate(true),
		"age": age,
		"day_phase": day_phase,
		"weather": weather,
		"temperature_bias": temperature_bias
	}


func deserialize_state(data: Dictionary) -> void:
	if data.has("seed"):
		last_seed = int(data["seed"])
		rng.seed = last_seed
	if data.has("grid") and typeof(data["grid"]) == TYPE_ARRAY:
		grid = data["grid"]
		_rebuild_special_cell_lists()
	if data.has("resource_energy") and typeof(data["resource_energy"]) == TYPE_DICTIONARY:
		resource_energy = data["resource_energy"]
	age = float(data.get("age", age))
	day_phase = float(data.get("day_phase", day_phase))
	weather = str(data.get("weather", weather))
	temperature_bias = float(data.get("temperature_bias", temperature_bias))
	queue_redraw()


func get_spawn_position() -> Vector2:
	return world_from_cell(Vector2i(7, 7))


func cell_from_world(world_position: Vector2) -> Vector2i:
	return Vector2i(
		int(floor(world_position.x / CELL_SIZE)),
		int(floor(world_position.y / CELL_SIZE))
	)


func world_from_cell(cell: Vector2i) -> Vector2:
	return Vector2(
		float(cell.x * CELL_SIZE) + CELL_SIZE * 0.5,
		float(cell.y * CELL_SIZE) + CELL_SIZE * 0.5
	)


func is_inside(cell: Vector2i) -> bool:
	return cell.x >= 0 and cell.y >= 0 and cell.x < WORLD_SIZE.x and cell.y < WORLD_SIZE.y


func get_cell(cell: Vector2i) -> int:
	if not is_inside(cell):
		return Cell.WALL
	return int(grid[cell.y][cell.x])


func set_cell(cell: Vector2i, value: int) -> void:
	if not is_inside(cell):
		return
	if int(grid[cell.y][cell.x]) == Cell.RESOURCE:
		resource_energy.erase(_key(cell))
	grid[cell.y][cell.x] = value
	if value == Cell.RESOURCE:
		resource_energy[_key(cell)] = 1.0
	if value == Cell.SAFE and not safe_cells.has(cell):
		safe_cells.append(cell)
	if value == Cell.CHARGER and not charger_cells.has(cell):
		charger_cells.append(cell)


func is_cell_blocked(cell: Vector2i) -> bool:
	return get_cell(cell) == Cell.WALL


func can_move_to(world_position: Vector2, radius: float) -> bool:
	var offsets := [
		Vector2.ZERO,
		Vector2(radius, 0.0),
		Vector2(-radius, 0.0),
		Vector2(0.0, radius),
		Vector2(0.0, -radius),
		Vector2(radius * 0.7, radius * 0.7),
		Vector2(-radius * 0.7, radius * 0.7),
		Vector2(radius * 0.7, -radius * 0.7),
		Vector2(-radius * 0.7, -radius * 0.7)
	]
	for offset in offsets:
		if is_cell_blocked(cell_from_world(world_position + offset)):
			return false
	return true


func sample_at(world_position: Vector2) -> Dictionary:
	var cell := cell_from_world(world_position)
	var cell_type := get_cell(cell)
	var key := _key(cell)
	var danger := 0.0
	var safety := 0.0
	var energy := 0.0
	var temperature := temperature_bias

	match cell_type:
		Cell.DANGER:
			danger = 1.0
		Cell.SAFE:
			safety = 1.0
			temperature *= 0.35
		Cell.RESOURCE:
			energy = float(resource_energy.get(key, 1.0))
		Cell.CHARGER:
			energy = 0.8
			safety = 0.65
		Cell.HOT:
			temperature += 0.75
		Cell.COLD:
			temperature -= 0.75
		Cell.ENERGY_FIELD:
			energy = 0.25
			danger = 0.18

	return {
		"cell": cell,
		"type": cell_type,
		"blocked": cell_type == Cell.WALL,
		"resource": cell_type == Cell.RESOURCE,
		"charger": cell_type == Cell.CHARGER,
		"safe_zone": cell_type == Cell.SAFE or cell_type == Cell.CHARGER,
		"danger": danger,
		"safety": safety,
		"energy": energy,
		"temperature": temperature,
		"light": get_light_level(),
		"weather": weather
	}


func consume_resource_at(world_position: Vector2, amount: float) -> float:
	var cell := cell_from_world(world_position)
	if get_cell(cell) != Cell.RESOURCE:
		return 0.0
	var key := _key(cell)
	var stored := float(resource_energy.get(key, 0.0))
	var taken := min(stored, amount)
	stored -= taken
	if stored <= 0.02:
		resource_energy.erase(key)
		grid[cell.y][cell.x] = Cell.EMPTY
	else:
		resource_energy[key] = stored
	queue_redraw()
	return taken


func get_light_level() -> float:
	var wave := sin(day_phase * TAU - PI * 0.5) * 0.5 + 0.5
	return clamp(0.18 + wave * 0.82, 0.0, 1.0)


func find_nearest_known_cell(origin: Vector2, cell_types: Array, max_cells: int = 90) -> Vector2i:
	var origin_cell := cell_from_world(origin)
	var best := Vector2i(-1, -1)
	var best_dist := INF
	for y in range(WORLD_SIZE.y):
		for x in range(WORLD_SIZE.x):
			var cell := Vector2i(x, y)
			if cell_types.has(get_cell(cell)):
				var dist := origin_cell.distance_to(cell)
				if dist < best_dist and dist <= max_cells:
					best_dist = dist
					best = cell
	return best


func random_floor_position() -> Vector2:
	for attempt in range(120):
		var cell := Vector2i(rng.randi_range(2, WORLD_SIZE.x - 3), rng.randi_range(2, WORLD_SIZE.y - 3))
		if get_cell(cell) == Cell.EMPTY:
			return world_from_cell(cell)
	return get_spawn_position()


func _draw() -> void:
	var world_rect := Rect2(Vector2.ZERO, Vector2(WORLD_SIZE.x * CELL_SIZE, WORLD_SIZE.y * CELL_SIZE))
	draw_rect(world_rect, Color8(2, 5, 12), true)

	for y in range(WORLD_SIZE.y):
		for x in range(WORLD_SIZE.x):
			var cell := Vector2i(x, y)
			var cell_type := get_cell(cell)
			var rect := Rect2(Vector2(x * CELL_SIZE, y * CELL_SIZE), Vector2(CELL_SIZE, CELL_SIZE))
			var color := _cell_color(cell_type)
			if color.a > 0.01:
				draw_rect(rect.grow(-1.0), color, true)

	var grid_color := Color8(50, 80, 100, 18)
	for x in range(0, WORLD_SIZE.x + 1, 4):
		var px := x * CELL_SIZE
		draw_line(Vector2(px, 0), Vector2(px, WORLD_SIZE.y * CELL_SIZE), grid_color, 1.0)
	for y in range(0, WORLD_SIZE.y + 1, 4):
		var py := y * CELL_SIZE
		draw_line(Vector2(0, py), Vector2(WORLD_SIZE.x * CELL_SIZE, py), grid_color, 1.0)

	var night_alpha := int((1.0 - get_light_level()) * 105.0)
	if night_alpha > 0:
		draw_rect(world_rect, Color8(0, 8, 22, night_alpha), true)


func _cell_color(cell_type: int) -> Color:
	match cell_type:
		Cell.EMPTY:
			return Color8(5, 12, 22, 190)
		Cell.WALL:
			return Color8(45, 60, 76, 235)
		Cell.DANGER:
			return Color8(178, 36, 62, 205)
		Cell.SAFE:
			return Color8(38, 145, 132, 155)
		Cell.RESOURCE:
			return Color8(90, 220, 166, 230)
		Cell.CHARGER:
			return Color8(70, 150, 255, 230)
		Cell.HOT:
			return Color8(210, 100, 45, 125)
		Cell.COLD:
			return Color8(65, 120, 210, 125)
		Cell.ENERGY_FIELD:
			return Color8(140, 110, 255, 155)
	return Color(0.0, 0.0, 0.0, 0.0)


func _build_base_grid() -> void:
	grid.clear()
	for y in range(WORLD_SIZE.y):
		var row := []
		for x in range(WORLD_SIZE.x):
			var border := x == 0 or y == 0 or x == WORLD_SIZE.x - 1 or y == WORLD_SIZE.y - 1
			row.append(Cell.WALL if border else Cell.EMPTY)
		grid.append(row)


func _add_structural_obstacles() -> void:
	for i in range(330):
		var cell := Vector2i(rng.randi_range(2, WORLD_SIZE.x - 3), rng.randi_range(2, WORLD_SIZE.y - 3))
		if cell.distance_to(Vector2i(7, 7)) > 7.0:
			grid[cell.y][cell.x] = Cell.WALL

	for i in range(22):
		var start := Vector2i(rng.randi_range(4, WORLD_SIZE.x - 5), rng.randi_range(4, WORLD_SIZE.y - 5))
		var length := rng.randi_range(4, 11)
		var horizontal := rng.randf() > 0.5
		for n in range(length):
			var cell := start + (Vector2i(n, 0) if horizontal else Vector2i(0, n))
			if is_inside(cell) and cell.distance_to(Vector2i(7, 7)) > 7.0:
				grid[cell.y][cell.x] = Cell.WALL


func _carve_primary_paths() -> void:
	var mid_y := int(WORLD_SIZE.y / 2)
	var mid_x := int(WORLD_SIZE.x / 2)
	for x in range(2, WORLD_SIZE.x - 2):
		grid[mid_y][x] = Cell.EMPTY
		if rng.randf() > 0.68:
			grid[clamp(mid_y + rng.randi_range(-1, 1), 1, WORLD_SIZE.y - 2)][x] = Cell.EMPTY
	for y in range(2, WORLD_SIZE.y - 2):
		grid[y][mid_x] = Cell.EMPTY
		if rng.randf() > 0.68:
			grid[y][clamp(mid_x + rng.randi_range(-1, 1), 1, WORLD_SIZE.x - 2)] = Cell.EMPTY
	for x in range(2, 16):
		for y in range(2, 14):
			grid[y][x] = Cell.EMPTY


func _add_safe_and_charge_zones() -> void:
	var zones := [Vector2i(7, 7), Vector2i(WORLD_SIZE.x - 8, WORLD_SIZE.y - 8), Vector2i(10, WORLD_SIZE.y - 9)]
	for center in zones:
		_paint_disc(center, 3, Cell.SAFE, true)
		set_cell(center, Cell.CHARGER)
	for cell in [Vector2i(WORLD_SIZE.x - 10, 9), Vector2i(WORLD_SIZE.x / 2, WORLD_SIZE.y - 8)]:
		_paint_disc(cell, 2, Cell.SAFE, true)


func _add_thermal_fields() -> void:
	for i in range(5):
		_paint_disc(
			Vector2i(rng.randi_range(9, WORLD_SIZE.x - 10), rng.randi_range(9, WORLD_SIZE.y - 10)),
			rng.randi_range(3, 6),
			Cell.HOT if rng.randf() > 0.5 else Cell.COLD,
			false
		)
	for i in range(4):
		_paint_disc(
			Vector2i(rng.randi_range(8, WORLD_SIZE.x - 9), rng.randi_range(8, WORLD_SIZE.y - 9)),
			rng.randi_range(2, 4),
			Cell.ENERGY_FIELD,
			false
		)


func _add_danger_regions() -> void:
	for i in range(9):
		var center := Vector2i(rng.randi_range(10, WORLD_SIZE.x - 10), rng.randi_range(8, WORLD_SIZE.y - 8))
		if center.distance_to(Vector2i(7, 7)) > 12.0:
			_paint_disc(center, rng.randi_range(2, 5), Cell.DANGER, false)


func _spawn_initial_resources() -> void:
	for i in range(MAX_RESOURCES):
		_try_spawn_resource()


func _try_spawn_resource() -> void:
	if resource_energy.size() >= MAX_RESOURCES:
		return
	for attempt in range(40):
		var cell := Vector2i(rng.randi_range(2, WORLD_SIZE.x - 3), rng.randi_range(2, WORLD_SIZE.y - 3))
		if get_cell(cell) == Cell.EMPTY:
			set_cell(cell, Cell.RESOURCE)
			resource_energy[_key(cell)] = rng.randf_range(0.35, 1.0)
			return


func _evolve_danger() -> void:
	var candidates := []
	for y in range(1, WORLD_SIZE.y - 1):
		for x in range(1, WORLD_SIZE.x - 1):
			var cell := Vector2i(x, y)
			if get_cell(cell) == Cell.DANGER:
				for direction in [Vector2i.RIGHT, Vector2i.LEFT, Vector2i.UP, Vector2i.DOWN]:
					var neighbor := cell + direction
					if get_cell(neighbor) == Cell.EMPTY and rng.randf() < 0.012:
						candidates.append(neighbor)
	for candidate in candidates:
		if candidate.distance_to(Vector2i(7, 7)) > 8.0:
			set_cell(candidate, Cell.DANGER)

	for i in range(14):
		var cell := Vector2i(rng.randi_range(2, WORLD_SIZE.x - 3), rng.randi_range(2, WORLD_SIZE.y - 3))
		if get_cell(cell) == Cell.DANGER and rng.randf() < 0.18:
			set_cell(cell, Cell.EMPTY)


func _roll_environment_event() -> void:
	var roll := rng.randf()
	if roll < 0.25:
		weather = "ion wind"
		temperature_bias = rng.randf_range(-0.15, 0.15)
	elif roll < 0.50:
		weather = "cold drift"
		temperature_bias = -0.28
	elif roll < 0.75:
		weather = "thermal swell"
		temperature_bias = 0.32
	else:
		weather = "clear"
		temperature_bias = 0.0
	emit_signal("world_event", weather, {"age": age})


func _paint_disc(center: Vector2i, radius: int, value: int, allow_safe_overwrite: bool) -> void:
	for y in range(center.y - radius, center.y + radius + 1):
		for x in range(center.x - radius, center.x + radius + 1):
			var cell := Vector2i(x, y)
			if not is_inside(cell):
				continue
			if cell.x == 0 or cell.y == 0 or cell.x == WORLD_SIZE.x - 1 or cell.y == WORLD_SIZE.y - 1:
				continue
			if center.distance_to(cell) > radius:
				continue
			var existing := get_cell(cell)
			if existing == Cell.CHARGER:
				continue
			if not allow_safe_overwrite and existing == Cell.SAFE:
				continue
			if existing != Cell.WALL or allow_safe_overwrite:
				set_cell(cell, value)


func _rebuild_special_cell_lists() -> void:
	safe_cells.clear()
	charger_cells.clear()
	resource_energy.clear()
	for y in range(min(grid.size(), WORLD_SIZE.y)):
		for x in range(min(grid[y].size(), WORLD_SIZE.x)):
			var cell := Vector2i(x, y)
			var cell_type := get_cell(cell)
			if cell_type == Cell.SAFE:
				safe_cells.append(cell)
			elif cell_type == Cell.CHARGER:
				charger_cells.append(cell)
			elif cell_type == Cell.RESOURCE:
				resource_energy[_key(cell)] = 1.0


func _key(cell: Vector2i) -> String:
	return "%d:%d" % [cell.x, cell.y]
