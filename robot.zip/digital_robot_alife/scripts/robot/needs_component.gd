class_name NeedsComponent
extends RefCounted

var energy := 0.72
var stress := 0.18
var damage := 0.0
var confidence := 0.14
var familiarity := 0.0
var curiosity := 0.82
var fatigue := 0.0
var fear_memory := 0.0
var adaptation_level := 0.0
var age := 0.0
var shutdown := false


func update(delta: float, sample: Dictionary, movement_speed: float, active_action: String) -> void:
	age += delta
	var movement_cost := clamp(movement_speed / 90.0, 0.0, 1.8) * 0.010
	var sensor_cost := 0.003
	energy = clamp(energy - delta * (0.004 + movement_cost + sensor_cost), 0.0, 1.0)

	var light := float(sample.get("light", 0.5))
	if light < 0.30:
		stress += delta * 0.008

	var temperature := abs(float(sample.get("temperature", 0.0)))
	if temperature > 0.45:
		stress += delta * temperature * 0.018
		fatigue += delta * temperature * 0.020

	if float(sample.get("safety", 0.0)) > 0.2:
		stress = max(0.0, stress - delta * 0.040)
		fatigue = max(0.0, fatigue - delta * 0.025)
		damage = max(0.0, damage - delta * 0.016)

	if active_action == "rest":
		fatigue = max(0.0, fatigue - delta * 0.055)
		stress = max(0.0, stress - delta * 0.018)
	else:
		fatigue = clamp(fatigue + delta * 0.004, 0.0, 1.0)

	if energy < 0.06:
		damage = clamp(damage + delta * 0.020, 0.0, 1.0)
		stress = clamp(stress + delta * 0.030, 0.0, 1.0)

	curiosity = clamp(curiosity + delta * (0.010 + confidence * 0.008) - stress * delta * 0.012, 0.0, 1.0)
	fear_memory = clamp(fear_memory * pow(0.998, delta * 60.0), 0.0, 1.0)
	confidence = clamp(confidence - stress * delta * 0.010 + familiarity * delta * 0.008, 0.0, 1.0)
	shutdown = energy <= 0.001 or damage >= 0.995


func apply_energy(amount: float) -> void:
	energy = clamp(energy + amount, 0.0, 1.0)
	if amount > 0.0:
		confidence = clamp(confidence + amount * 0.10, 0.0, 1.0)


func apply_damage(amount: float) -> void:
	damage = clamp(damage + amount, 0.0, 1.0)
	stress = clamp(stress + amount * 0.75, 0.0, 1.0)
	fear_memory = clamp(fear_memory + amount * 0.90, 0.0, 1.0)
	confidence = clamp(confidence - amount * 0.40, 0.0, 1.0)
	shutdown = energy <= 0.001 or damage >= 0.995


func repair(amount: float) -> void:
	damage = clamp(damage - amount, 0.0, 1.0)
	if amount > 0.0:
		confidence = clamp(confidence + amount * 0.15, 0.0, 1.0)


func apply_learning_feedback(reward: float) -> void:
	if reward > 0.0:
		confidence = clamp(confidence + reward * 0.018, 0.0, 1.0)
		adaptation_level = clamp(adaptation_level + reward * 0.012, 0.0, 1.0)
	else:
		stress = clamp(stress + abs(reward) * 0.012, 0.0, 1.0)
	adaptation_level = clamp(adaptation_level + 0.00008, 0.0, 1.0)


func priorities() -> Dictionary:
	var energy_need := clamp(1.0 - energy, 0.0, 1.0)
	var safety_need := clamp(stress * 0.65 + damage * 0.55 + fear_memory * 0.45, 0.0, 1.0)
	var recovery_need := clamp(damage * 0.85 + fatigue * 0.45 + (1.0 - energy) * 0.20, 0.0, 1.0)
	var curiosity_need := clamp(curiosity * energy * (1.0 - stress * 0.65), 0.0, 1.0)
	var stability_need := clamp(1.0 - familiarity + stress * 0.35, 0.0, 1.0)
	return {
		"energy": energy_need,
		"safety": safety_need,
		"recovery": recovery_need,
		"curiosity": curiosity_need,
		"stability": stability_need
	}


func snapshot() -> Dictionary:
	return {
		"energy": energy,
		"stress": stress,
		"damage": damage,
		"confidence": confidence,
		"familiarity": familiarity,
		"curiosity": curiosity,
		"fatigue": fatigue,
		"fear_memory": fear_memory,
		"adaptation_level": adaptation_level,
		"age": age,
		"shutdown": shutdown
	}


func serialize_state() -> Dictionary:
	return snapshot()


func deserialize_state(data: Dictionary) -> void:
	energy = float(data.get("energy", energy))
	stress = float(data.get("stress", stress))
	damage = float(data.get("damage", damage))
	confidence = float(data.get("confidence", confidence))
	familiarity = float(data.get("familiarity", familiarity))
	curiosity = float(data.get("curiosity", curiosity))
	fatigue = float(data.get("fatigue", fatigue))
	fear_memory = float(data.get("fear_memory", fear_memory))
	adaptation_level = float(data.get("adaptation_level", adaptation_level))
	age = float(data.get("age", age))
	shutdown = bool(data.get("shutdown", shutdown))
