class_name MemoryComponent
extends RefCounted

var short_term: Array = []
var spatial_memory: Dictionary = {}
var action_memory: Dictionary = {}
var route_memory: Array = []
var max_short_term := 90
var max_route_points := 220
var decay_clock := 0.0
var last_reward := 0.0


func observe(observations: Dictionary, position: Vector2, needs: NeedsComponent, world_age: float) -> void:
	var ambient: Dictionary = observations.get("ambient", {})
	if ambient.has("cell"):
		_mark_cell(ambient["cell"], ambient, 1.0, world_age)
		needs.familiarity = get_familiarity(ambient["cell"])
		short_term.append({
			"cell": _key(ambient["cell"]),
			"danger": float(ambient.get("danger", 0.0)),
			"energy": float(ambient.get("energy", 0.0)),
			"safety": float(ambient.get("safety", 0.0)),
			"age": world_age
		})

	for ray in observations.get("rays", []):
		if typeof(ray) == TYPE_DICTIONARY and ray.has("cell"):
			var intensity := clamp(1.0 - float(ray.get("distance", 999.0)) / 260.0, 0.12, 0.85)
			_mark_cell(ray["cell"], ray, intensity, world_age)

	route_memory.append(_key(world_cell_from_position(position)))
	while short_term.size() > max_short_term:
		short_term.pop_front()
	while route_memory.size() > max_route_points:
		route_memory.pop_front()

	decay_clock += 1.0
	if decay_clock >= 10.0:
		decay_clock = 0.0
		_decay_memories()


func remember_result(decision: Dictionary, reward: float, position: Vector2, sample: Dictionary, world_age: float) -> void:
	last_reward = reward
	var action := str(decision.get("action", "unknown"))
	if not action_memory.has(action):
		action_memory[action] = {"uses": 0, "reward": 0.0, "failures": 0, "successes": 0}
	var entry: Dictionary = action_memory[action]
	entry["uses"] = int(entry["uses"]) + 1
	entry["reward"] = lerp(float(entry["reward"]), reward, 0.08)
	if reward >= 0.0:
		entry["successes"] = int(entry["successes"]) + 1
	else:
		entry["failures"] = int(entry["failures"]) + 1
	action_memory[action] = entry

	if sample.has("cell"):
		_mark_cell(sample["cell"], sample, 1.0 + clamp(abs(reward), 0.0, 1.0), world_age)
		var key := _key(sample["cell"])
		var cell_entry: Dictionary = spatial_memory[key]
		cell_entry["reward"] = lerp(float(cell_entry["reward"]), reward, 0.12)
		if reward < -0.05:
			cell_entry["fear"] = clamp(float(cell_entry["fear"]) + abs(reward) * 0.20, 0.0, 1.0)
		if reward > 0.05:
			cell_entry["confidence"] = clamp(float(cell_entry["confidence"]) + reward * 0.14, 0.0, 1.0)
		spatial_memory[key] = cell_entry


func get_familiarity(cell: Vector2i) -> float:
	var key := _key(cell)
	if not spatial_memory.has(key):
		return 0.0
	var entry: Dictionary = spatial_memory[key]
	return clamp(float(entry.get("familiarity", 0.0)), 0.0, 1.0)


func known_value(cell: Vector2i, property: String) -> float:
	var key := _key(cell)
	if not spatial_memory.has(key):
		return 0.0
	return float(spatial_memory[key].get(property, 0.0))


func find_best_cell(kind: String, origin_cell: Vector2i, max_distance: float = 60.0) -> Vector2i:
	var best_cell := Vector2i(-1, -1)
	var best_score := -INF
	for key in spatial_memory.keys():
		var cell := _cell_from_key(str(key))
		var entry: Dictionary = spatial_memory[key]
		var distance := origin_cell.distance_to(cell)
		if distance > max_distance:
			continue
		var score := -distance * 0.015 - float(entry.get("danger", 0.0)) * 1.45 - float(entry.get("fear", 0.0)) * 0.75
		match kind:
			"energy":
				score += float(entry.get("energy", 0.0)) * 2.0 + float(entry.get("charger", 0.0)) * 1.6
			"safe":
				score += float(entry.get("safety", 0.0)) * 2.0 + float(entry.get("confidence", 0.0)) * 0.35
			"charger":
				score += float(entry.get("charger", 0.0)) * 2.8 + float(entry.get("safety", 0.0)) * 0.6
			"calm":
				score += float(entry.get("safety", 0.0)) * 1.3 - abs(float(entry.get("temperature", 0.0))) * 0.4
			_:
				score += float(entry.get("reward", 0.0))
		if score > best_score:
			best_score = score
			best_cell = cell
	return best_cell


func get_exploration_vector(world, position: Vector2) -> Vector2:
	var origin := world.cell_from_world(position)
	var best_vector := Vector2.ZERO
	var best_score := -INF
	for y in range(-10, 11, 2):
		for x in range(-10, 11, 2):
			if x == 0 and y == 0:
				continue
			var cell := origin + Vector2i(x, y)
			if not world.is_inside(cell) or world.is_cell_blocked(cell):
				continue
			var key := _key(cell)
			var visits := 0.0
			var danger := 0.0
			var confidence := 0.0
			if spatial_memory.has(key):
				var entry: Dictionary = spatial_memory[key]
				visits = float(entry.get("visits", 0.0))
				danger = float(entry.get("danger", 0.0)) + float(entry.get("fear", 0.0))
				confidence = float(entry.get("confidence", 0.0))
			var distance := max(1.0, origin.distance_to(cell))
			var novelty := 1.0 / (1.0 + visits * 0.35)
			var score := novelty + confidence * 0.15 - danger * 1.6 - distance * 0.018
			if score > best_score:
				best_score = score
				best_vector = (world.world_from_cell(cell) - position).normalized()
	return best_vector


func snapshot() -> Dictionary:
	return {
		"known_cells": spatial_memory.size(),
		"short_term": short_term.size(),
		"actions": action_memory.duplicate(true),
		"last_reward": last_reward,
		"route_points": route_memory.size()
	}


func serialize_state() -> Dictionary:
	return {
		"spatial_memory": spatial_memory.duplicate(true),
		"action_memory": action_memory.duplicate(true),
		"route_memory": route_memory.duplicate(),
		"last_reward": last_reward
	}


func deserialize_state(data: Dictionary) -> void:
	if data.has("spatial_memory") and typeof(data["spatial_memory"]) == TYPE_DICTIONARY:
		spatial_memory = data["spatial_memory"]
	if data.has("action_memory") and typeof(data["action_memory"]) == TYPE_DICTIONARY:
		action_memory = data["action_memory"]
	if data.has("route_memory") and typeof(data["route_memory"]) == TYPE_ARRAY:
		route_memory = data["route_memory"]
	last_reward = float(data.get("last_reward", last_reward))


func world_cell_from_position(position: Vector2) -> Vector2i:
	return Vector2i(int(floor(position.x / 18.0)), int(floor(position.y / 18.0)))


func _mark_cell(cell: Vector2i, sample: Dictionary, intensity: float, world_age: float) -> void:
	var key := _key(cell)
	var entry: Dictionary
	if spatial_memory.has(key):
		entry = spatial_memory[key]
	else:
		entry = _new_entry()

	entry["visits"] = float(entry["visits"]) + intensity
	entry["last_seen"] = world_age
	entry["familiarity"] = clamp(float(entry["familiarity"]) + 0.018 * intensity, 0.0, 1.0)
	entry["danger"] = clamp(max(float(entry["danger"]) * 0.985, float(sample.get("danger", 0.0)) * intensity), 0.0, 1.0)
	entry["safety"] = clamp(max(float(entry["safety"]) * 0.990, float(sample.get("safety", 0.0)) * intensity), 0.0, 1.0)
	entry["energy"] = clamp(max(float(entry["energy"]) * 0.975, float(sample.get("energy", 0.0)) * intensity), 0.0, 1.0)
	entry["temperature"] = lerp(float(entry["temperature"]), float(sample.get("temperature", 0.0)), 0.20 * intensity)
	entry["charger"] = max(float(entry["charger"]), 1.0 if bool(sample.get("charger", false)) else 0.0)

	if float(sample.get("danger", 0.0)) > 0.1:
		entry["fear"] = clamp(float(entry["fear"]) + float(sample.get("danger", 0.0)) * 0.05 * intensity, 0.0, 1.0)
	if float(sample.get("safety", 0.0)) > 0.1 or float(sample.get("energy", 0.0)) > 0.1:
		entry["confidence"] = clamp(float(entry["confidence"]) + 0.018 * intensity, 0.0, 1.0)

	spatial_memory[key] = entry


func _decay_memories() -> void:
	var remove_keys := []
	for key in spatial_memory.keys():
		var entry: Dictionary = spatial_memory[key]
		entry["danger"] = float(entry["danger"]) * 0.992
		entry["safety"] = float(entry["safety"]) * 0.996
		entry["energy"] = float(entry["energy"]) * 0.986
		entry["fear"] = float(entry["fear"]) * 0.997
		entry["confidence"] = float(entry["confidence"]) * 0.999
		if float(entry["visits"]) < 0.3 and float(entry["familiarity"]) < 0.08:
			remove_keys.append(key)
		else:
			spatial_memory[key] = entry
	for key in remove_keys:
		spatial_memory.erase(key)


func _new_entry() -> Dictionary:
	return {
		"visits": 0.0,
		"last_seen": 0.0,
		"familiarity": 0.0,
		"danger": 0.0,
		"safety": 0.0,
		"energy": 0.0,
		"temperature": 0.0,
		"charger": 0.0,
		"reward": 0.0,
		"fear": 0.0,
		"confidence": 0.0
	}


func _key(cell: Vector2i) -> String:
	return "%d:%d" % [cell.x, cell.y]


func _cell_from_key(key: String) -> Vector2i:
	var parts := key.split(":")
	if parts.size() != 2:
		return Vector2i.ZERO
	return Vector2i(int(parts[0]), int(parts[1]))
