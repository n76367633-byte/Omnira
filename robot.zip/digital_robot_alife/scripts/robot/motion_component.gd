class_name MotionComponent
extends RefCounted

var max_speed := 78.0
var acceleration := 170.0
var turn_rate := 4.2
var collision_cooldown := 0.0


func apply(decision: Dictionary, delta: float, world, robot) -> Dictionary:
	var direction: Vector2 = decision.get("move_vector", Vector2.RIGHT.rotated(robot.heading))
	if direction.length() < 0.01:
		direction = Vector2.RIGHT.rotated(robot.heading)
	direction = direction.normalized()

	var desired_heading := direction.angle()
	var diff := wrapf(desired_heading - robot.heading, -PI, PI)
	var turn_amount := clamp(diff, -turn_rate * delta, turn_rate * delta)
	robot.heading = wrapf(robot.heading + turn_amount, -PI, PI)

	var desired_speed := float(decision.get("desired_speed", 0.5)) * max_speed
	var desired_velocity := Vector2.RIGHT.rotated(robot.heading) * desired_speed
	robot.velocity = robot.velocity.move_toward(desired_velocity, acceleration * delta)

	var old_position: Vector2 = robot.position
	var next_position := old_position + robot.velocity * delta
	var collided := false
	if world.can_move_to(next_position, robot.body_radius):
		robot.position = next_position
	else:
		var slide_x := Vector2(next_position.x, old_position.y)
		var slide_y := Vector2(old_position.x, next_position.y)
		if world.can_move_to(slide_x, robot.body_radius):
			robot.position = slide_x
			robot.velocity.y *= -0.18
			collided = true
		elif world.can_move_to(slide_y, robot.body_radius):
			robot.position = slide_y
			robot.velocity.x *= -0.18
			collided = true
		else:
			robot.velocity *= -0.12
			robot.heading = wrapf(robot.heading + PI * 0.42, -PI, PI)
			collided = true

	if collided:
		collision_cooldown = 0.35
	else:
		collision_cooldown = max(0.0, collision_cooldown - delta)

	return {
		"collided": collided,
		"distance": old_position.distance_to(robot.position),
		"speed": robot.velocity.length()
	}
