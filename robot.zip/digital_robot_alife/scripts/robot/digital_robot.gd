class_name DigitalRobot
extends Node2D

const NeedsComponentScript := preload("res://scripts/robot/needs_component.gd")
const SensorsComponentScript := preload("res://scripts/robot/sensors_component.gd")
const MemoryComponentScript := preload("res://scripts/robot/memory_component.gd")
const LearningComponentScript := preload("res://scripts/robot/learning_component.gd")
const BrainComponentScript := preload("res://scripts/robot/brain_component.gd")
const MotionComponentScript := preload("res://scripts/robot/motion_component.gd")

var world
var needs: NeedsComponent
var sensors: SensorsComponent
var memory: MemoryComponent
var learning: LearningComponent
var brain: BrainComponent
var motion: MotionComponent

var heading := 0.0
var velocity := Vector2.ZERO
var body_radius := 8.5
var current_decision: Dictionary = {"action": "wake"}
var last_observations: Dictionary = {}
var last_reward := 0.0
var shutdown_timer := 0.0


func _init() -> void:
	needs = NeedsComponentScript.new()
	sensors = SensorsComponentScript.new()
	memory = MemoryComponentScript.new()
	learning = LearningComponentScript.new()
	brain = BrainComponentScript.new()
	motion = MotionComponentScript.new()


func configure(world_node) -> void:
	world = world_node
	position = world.get_spawn_position()
	heading = 0.0
	velocity = Vector2.ZERO
	current_decision = {"action": "wake"}
	queue_redraw()


func step(delta: float) -> void:
	if world == null:
		return

	if needs.shutdown:
		_shutdown_recovery(delta)
		queue_redraw()
		return

	var active_action := str(current_decision.get("action", "wake"))
	var observations := sensors.scan(world, position, heading, needs)
	last_observations = observations
	var sample := world.sample_at(position)
	memory.observe(observations, position, needs, world.age)
	needs.update(delta, sample, velocity.length(), active_action)

	var before := needs.snapshot()
	var decision := brain.decide(world, observations, needs, memory, learning, position, heading)
	current_decision = decision
	var motion_result := motion.apply(decision, delta, world, self)
	var after_sample := world.sample_at(position)
	_apply_environment(after_sample, delta)
	var post_observations := sensors.scan(world, position, heading, needs)
	var after := needs.snapshot()
	last_reward = _evaluate_result(before, after, decision, motion_result, after_sample, observations, post_observations)
	var next_context := learning.context_bucket(needs, post_observations)
	learning.learn(decision, last_reward, next_context)
	memory.remember_result(decision, last_reward, position, after_sample, world.age)
	needs.apply_learning_feedback(last_reward)
	last_observations = post_observations
	queue_redraw()


func snapshot() -> Dictionary:
	return {
		"position": position,
		"heading": heading,
		"velocity": velocity,
		"action": str(current_decision.get("action", "wake")),
		"exploratory": bool(current_decision.get("exploratory", false)),
		"reward": last_reward,
		"needs": needs.snapshot(),
		"memory": memory.snapshot(),
		"learning": learning.snapshot()
	}


func serialize_state() -> Dictionary:
	return {
		"position": [position.x, position.y],
		"heading": heading,
		"velocity": [velocity.x, velocity.y],
		"needs": needs.serialize_state(),
		"memory": memory.serialize_state(),
		"learning": learning.serialize_state()
	}


func deserialize_state(data: Dictionary) -> void:
	if data.has("position") and typeof(data["position"]) == TYPE_ARRAY and data["position"].size() >= 2:
		position = Vector2(float(data["position"][0]), float(data["position"][1]))
	if data.has("heading"):
		heading = float(data["heading"])
	if data.has("velocity") and typeof(data["velocity"]) == TYPE_ARRAY and data["velocity"].size() >= 2:
		velocity = Vector2(float(data["velocity"][0]), float(data["velocity"][1]))
	if data.has("needs") and typeof(data["needs"]) == TYPE_DICTIONARY:
		needs.deserialize_state(data["needs"])
	if data.has("memory") and typeof(data["memory"]) == TYPE_DICTIONARY:
		memory.deserialize_state(data["memory"])
	if data.has("learning") and typeof(data["learning"]) == TYPE_DICTIONARY:
		learning.deserialize_state(data["learning"])


func _apply_environment(sample: Dictionary, delta: float) -> void:
	var danger := float(sample.get("danger", 0.0))
	var safety := float(sample.get("safety", 0.0))
	var energy_signal := float(sample.get("energy", 0.0))
	var temperature := abs(float(sample.get("temperature", 0.0)))

	if bool(sample.get("resource", false)):
		var taken := world.consume_resource_at(position, delta * 0.58)
		needs.apply_energy(taken * 0.78)
	elif bool(sample.get("charger", false)):
		needs.apply_energy(delta * 0.21)
		needs.repair(delta * 0.022)
	elif energy_signal > 0.1:
		needs.apply_energy(delta * 0.030 * energy_signal)

	if danger > 0.0:
		needs.apply_damage(delta * 0.052 * danger)
	if temperature > 0.55:
		needs.apply_damage(delta * 0.010 * temperature)
	if safety > 0.1:
		needs.repair(delta * 0.010 * safety)


func _evaluate_result(before: Dictionary, after: Dictionary, decision: Dictionary, motion_result: Dictionary, sample: Dictionary, old_observations: Dictionary, new_observations: Dictionary) -> float:
	var reward := 0.0
	reward += (float(after["energy"]) - float(before["energy"])) * 2.2
	reward += (float(before["damage"]) - float(after["damage"])) * 2.0
	reward += (float(before["stress"]) - float(after["stress"])) * 1.0
	reward += clamp(float(motion_result.get("distance", 0.0)) / 18.0, 0.0, 1.0) * 0.010

	if bool(motion_result.get("collided", false)):
		reward -= 0.20
	if float(sample.get("danger", 0.0)) > 0.0:
		reward -= 0.35 * float(sample.get("danger", 0.0))
	if bool(sample.get("resource", false)) or bool(sample.get("charger", false)):
		reward += 0.18

	var action := str(decision.get("action", ""))
	if action == "seek_energy" and float(after["energy"]) > float(before["energy"]):
		reward += 0.14
	if action == "avoid_danger" and float(new_observations.get("danger_intensity", 0.0)) < float(old_observations.get("danger_intensity", 0.0)):
		reward += 0.10
	if action == "explore" or action == "map_unknown":
		var cell := world.cell_from_world(position)
		reward += (1.0 - memory.get_familiarity(cell)) * 0.018

	return clamp(reward, -1.0, 1.0)


func _shutdown_recovery(delta: float) -> void:
	shutdown_timer += delta
	velocity = velocity.move_toward(Vector2.ZERO, 60.0 * delta)
	if shutdown_timer > 3.0:
		var sample := world.sample_at(position)
		if bool(sample.get("charger", false)) or bool(sample.get("safe_zone", false)):
			needs.apply_energy(delta * 0.12)
			needs.repair(delta * 0.030)
		else:
			needs.apply_energy(delta * 0.018)
			needs.repair(delta * 0.006)
		if needs.energy > 0.16 and needs.damage < 0.82:
			needs.shutdown = false
			shutdown_timer = 0.0


func _draw() -> void:
	_draw_sensor_field()
	var energy := needs.energy
	var stress := needs.stress
	var damage := needs.damage
	var core_color := Color8(
		clamp(int(55 + 120 * stress + 90 * damage), 0, 255),
		int(130 + 95 * energy),
		int(180 + 55 * needs.confidence),
		235
	)
	var shell_color := Color8(115, 145, 168, 235)
	var shadow_color := Color8(0, 0, 0, 90)

	draw_circle(Vector2(2, 3), body_radius + 5.0, shadow_color)
	draw_arc(Vector2.ZERO, body_radius + 5.0, 0.0, TAU, 36, Color8(60, 105, 128, 180), 2.0)
	draw_circle(Vector2.ZERO, body_radius + 2.0, shell_color)
	draw_circle(Vector2.ZERO, body_radius - 1.0, Color8(12, 22, 32, 245))
	draw_circle(Vector2.ZERO, body_radius * 0.48, core_color)

	var forward := Vector2.RIGHT.rotated(heading)
	var left := forward.rotated(2.35)
	var right := forward.rotated(-2.35)
	var nose := forward * (body_radius + 8.0)
	var nose_color := Color8(155, 220, 245, 220)
	draw_polygon([nose, left * (body_radius * 0.75), right * (body_radius * 0.75)], [nose_color, nose_color, nose_color])
	draw_line(Vector2.ZERO, forward * (body_radius + 13.0), Color8(150, 230, 255, 210), 2.0)

	if needs.shutdown:
		draw_arc(Vector2.ZERO, body_radius + 9.0, -PI * 0.15, PI * 1.25, 28, Color8(240, 60, 70, 230), 2.0)


func _draw_sensor_field() -> void:
	if last_observations.is_empty():
		return
	for ray in last_observations.get("rays", []):
		if typeof(ray) != TYPE_DICTIONARY:
			continue
		var endpoint: Vector2 = to_local(ray.get("point", global_position))
		var color := Color8(70, 135, 165, 28)
		if float(ray.get("danger", 0.0)) > 0.0:
			color = Color8(230, 70, 90, 70)
		elif float(ray.get("energy", 0.0)) > 0.0:
			color = Color8(90, 245, 180, 80)
		elif bool(ray.get("blocked", false)):
			color = Color8(160, 175, 190, 48)
		draw_line(Vector2.ZERO, endpoint, color, 1.0)
