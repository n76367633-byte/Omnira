class_name SensorsComponent
extends RefCounted

var ray_count := 25
var ray_length := 245.0
var field_of_view := PI * 145.0 / 180.0
var tactile_radius := 15.0


func scan(world, position: Vector2, heading: float, _needs: NeedsComponent) -> Dictionary:
	var rays := []
	var energy_vector := Vector2.ZERO
	var danger_vector := Vector2.ZERO
	var safe_vector := Vector2.ZERO
	var wall_pressure := Vector2.ZERO
	var danger_intensity := 0.0
	var energy_intensity := 0.0
	var safe_intensity := 0.0
	var nearest_distance := ray_length

	var ambient := world.sample_at(position)
	for i in range(ray_count):
		var ratio := 0.5
		if ray_count > 1:
			ratio = float(i) / float(ray_count - 1)
		var angle := heading - field_of_view * 0.5 + ratio * field_of_view
		var direction := Vector2.RIGHT.rotated(angle)
		var hit := _cast_ray(world, position, direction)
		rays.append(hit)

		var closeness := 1.0 - clamp(float(hit["distance"]) / ray_length, 0.0, 1.0)
		if bool(hit["blocked"]):
			wall_pressure -= direction * max(0.12, closeness)
		if float(hit["danger"]) > 0.0:
			danger_vector -= direction * (0.35 + closeness)
			danger_intensity = max(danger_intensity, float(hit["danger"]) * (0.4 + closeness))
			nearest_distance = min(nearest_distance, float(hit["distance"]))
		if float(hit["energy"]) > 0.0:
			energy_vector += direction * (float(hit["energy"]) + closeness * 0.45)
			energy_intensity = max(energy_intensity, float(hit["energy"]))
			nearest_distance = min(nearest_distance, float(hit["distance"]))
		if float(hit["safety"]) > 0.0:
			safe_vector += direction * (float(hit["safety"]) + closeness * 0.25)
			safe_intensity = max(safe_intensity, float(hit["safety"]))

	var tactile := _tactile_scan(world, position)
	if tactile.length() > 0.01:
		wall_pressure += tactile

	return {
		"ambient": ambient,
		"rays": rays,
		"energy_vector": energy_vector,
		"danger_vector": danger_vector,
		"safe_vector": safe_vector,
		"wall_pressure": wall_pressure,
		"danger_intensity": clamp(danger_intensity, 0.0, 1.0),
		"energy_intensity": clamp(energy_intensity, 0.0, 1.0),
		"safe_intensity": clamp(safe_intensity, 0.0, 1.0),
		"nearest_signal_distance": nearest_distance
	}


func _cast_ray(world, origin: Vector2, direction: Vector2) -> Dictionary:
	var distance := 0.0
	var step := 7.0
	var last_sample := world.sample_at(origin)
	while distance <= ray_length:
		var point := origin + direction * distance
		var sample := world.sample_at(point)
		last_sample = sample
		if bool(sample["blocked"]) or float(sample["danger"]) > 0.0 or float(sample["energy"]) > 0.0 or float(sample["safety"]) > 0.0:
			return {
				"point": point,
				"cell": sample["cell"],
				"distance": distance,
				"type": sample["type"],
				"blocked": sample["blocked"],
				"resource": sample["resource"],
				"charger": sample["charger"],
				"safe_zone": sample["safe_zone"],
				"danger": sample["danger"],
				"energy": sample["energy"],
				"safety": sample["safety"],
				"temperature": sample["temperature"]
			}
		distance += step

	var end_point := origin + direction * ray_length
	return {
		"point": end_point,
		"cell": last_sample["cell"],
		"distance": ray_length,
		"type": last_sample["type"],
		"blocked": false,
		"resource": false,
		"charger": false,
		"safe_zone": false,
		"danger": 0.0,
		"energy": 0.0,
		"safety": 0.0,
		"temperature": last_sample["temperature"]
	}


func _tactile_scan(world, position: Vector2) -> Vector2:
	var pressure := Vector2.ZERO
	for i in range(12):
		var angle := TAU * float(i) / 12.0
		var direction := Vector2.RIGHT.rotated(angle)
		var probe := position + direction * tactile_radius
		if not world.can_move_to(probe, 3.0):
			pressure -= direction
	return pressure.normalized() if pressure.length() > 0.01 else Vector2.ZERO
