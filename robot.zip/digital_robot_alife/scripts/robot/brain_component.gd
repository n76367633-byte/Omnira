class_name BrainComponent
extends RefCounted

const ACTIONS := [
	"explore",
	"seek_energy",
	"avoid_danger",
	"rest",
	"map_unknown",
	"return_safe"
]

var rng := RandomNumberGenerator.new()
var wander_angle := 0.0
var wander_timer := 0.0


func _init() -> void:
	rng.randomize()
	wander_angle = rng.randf_range(-PI, PI)


func decide(world, observations: Dictionary, needs: NeedsComponent, memory: MemoryComponent, learning: LearningComponent, position: Vector2, heading: float) -> Dictionary:
	var priorities := needs.priorities()
	var context := learning.context_bucket(needs, observations)
	var scores := {}
	for action in ACTIONS:
		scores[action] = learning.score_action(action, context)

	var danger_signal := float(observations.get("danger_intensity", 0.0))
	var energy_signal := float(observations.get("energy_intensity", 0.0))
	var safe_signal := float(observations.get("safe_intensity", 0.0))

	scores["seek_energy"] = float(scores["seek_energy"]) + float(priorities["energy"]) * 2.2 + energy_signal * 1.15
	scores["avoid_danger"] = float(scores["avoid_danger"]) + float(priorities["safety"]) * 2.1 + danger_signal * 2.4
	scores["rest"] = float(scores["rest"]) + float(priorities["recovery"]) * 1.7 + safe_signal * 0.30
	scores["map_unknown"] = float(scores["map_unknown"]) + float(priorities["stability"]) * 0.85 + float(priorities["curiosity"]) * 0.65
	scores["explore"] = float(scores["explore"]) + float(priorities["curiosity"]) * 1.35 + needs.confidence * 0.30
	scores["return_safe"] = float(scores["return_safe"]) + float(priorities["safety"]) * 1.15 + float(priorities["recovery"]) * 0.80

	if needs.energy < 0.18:
		scores["seek_energy"] = float(scores["seek_energy"]) + 1.8
		scores["return_safe"] = float(scores["return_safe"]) + 0.5
	if needs.damage > 0.35:
		scores["return_safe"] = float(scores["return_safe"]) + 1.1
		scores["rest"] = float(scores["rest"]) + 0.8
	if danger_signal > 0.40:
		scores["avoid_danger"] = float(scores["avoid_danger"]) + 1.4

	var exploratory := rng.randf() < learning.exploration_rate
	var chosen := ACTIONS[rng.randi_range(0, ACTIONS.size() - 1)] if exploratory else _highest_score(scores)
	var move_vector := _direction_for_action(chosen, world, observations, memory, position, heading)

	var danger_vector: Vector2 = observations.get("danger_vector", Vector2.ZERO)
	var wall_pressure: Vector2 = observations.get("wall_pressure", Vector2.ZERO)
	move_vector = _normalize_or_forward(move_vector + danger_vector * 0.85 + wall_pressure * 0.55, heading)

	var speed := 0.55
	match chosen:
		"avoid_danger":
			speed = 0.95
		"seek_energy":
			speed = 0.78
		"return_safe":
			speed = 0.68
		"rest":
			speed = 0.06 if needs.energy > 0.28 else 0.25
		"map_unknown":
			speed = 0.50
		"explore":
			speed = 0.58
	speed *= clamp(1.0 - needs.fatigue * 0.45, 0.35, 1.0)

	return {
		"action": chosen,
		"context": context,
		"move_vector": move_vector,
		"desired_speed": speed,
		"scores": scores,
		"exploratory": exploratory
	}


func _direction_for_action(action: String, world, observations: Dictionary, memory: MemoryComponent, position: Vector2, heading: float) -> Vector2:
	match action:
		"seek_energy":
			var direct_energy: Vector2 = observations.get("energy_vector", Vector2.ZERO)
			if direct_energy.length() > 0.05:
				return direct_energy.normalized()
			var energy_target := _target_vector(memory.find_best_cell("energy", world.cell_from_world(position)), world, position)
			if energy_target.length() > 0.05:
				return energy_target
		"avoid_danger":
			var danger_vector: Vector2 = observations.get("danger_vector", Vector2.ZERO)
			if danger_vector.length() > 0.05:
				return danger_vector.normalized()
			var calm_target := _target_vector(memory.find_best_cell("calm", world.cell_from_world(position)), world, position)
			if calm_target.length() > 0.05:
				return calm_target
		"rest", "return_safe":
			var safe_target := _target_vector(memory.find_best_cell("charger", world.cell_from_world(position)), world, position)
			if safe_target.length() > 0.05:
				return safe_target
			safe_target = _target_vector(memory.find_best_cell("safe", world.cell_from_world(position)), world, position)
			if safe_target.length() > 0.05:
				return safe_target
		"map_unknown":
			var exploration := memory.get_exploration_vector(world, position)
			if exploration.length() > 0.05:
				return exploration
		"explore":
			var exploratory := memory.get_exploration_vector(world, position)
			if exploratory.length() > 0.05:
				return exploratory * 0.65 + _wander(heading) * 0.35
	return _wander(heading)


func _wander(heading: float) -> Vector2:
	wander_timer -= 1.0
	if wander_timer <= 0.0:
		wander_timer = rng.randi_range(12, 50)
		wander_angle = wrapf(wander_angle + rng.randf_range(-0.8, 0.8), -PI, PI)
	var forward := Vector2.RIGHT.rotated(heading)
	var wandering := Vector2.RIGHT.rotated(wander_angle)
	return (forward * 0.55 + wandering * 0.45).normalized()


func _target_vector(cell: Vector2i, world, position: Vector2) -> Vector2:
	if cell.x < 0 or cell.y < 0:
		return Vector2.ZERO
	return (world.world_from_cell(cell) - position).normalized()


func _normalize_or_forward(vector: Vector2, heading: float) -> Vector2:
	if vector.length() < 0.02:
		return Vector2.RIGHT.rotated(heading)
	return vector.normalized()


func _highest_score(scores: Dictionary) -> String:
	var best_action := "explore"
	var best_score := -INF
	for action in scores.keys():
		var score := float(scores[action])
		if score > best_score:
			best_score = score
			best_action = str(action)
	return best_action
