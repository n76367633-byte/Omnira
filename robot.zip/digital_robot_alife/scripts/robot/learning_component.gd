class_name LearningComponent
extends RefCounted

const ACTIONS := [
	"explore",
	"seek_energy",
	"avoid_danger",
	"rest",
	"map_unknown",
	"return_safe"
]

var q_table: Dictionary = {}
var action_preferences: Dictionary = {}
var reward_trace: Array = []
var learning_rate := 0.12
var discount := 0.72
var exploration_rate := 0.28


func context_bucket(needs: NeedsComponent, observations: Dictionary) -> String:
	var parts := []
	parts.append("low_energy" if needs.energy < 0.32 else "energy_ok")
	parts.append("hurt" if needs.damage > 0.25 else "body_ok")
	parts.append("stressed" if needs.stress > 0.45 else "calm")
	parts.append("danger_seen" if float(observations.get("danger_intensity", 0.0)) > 0.25 else "danger_clear")
	parts.append("energy_seen" if float(observations.get("energy_intensity", 0.0)) > 0.20 else "energy_hidden")
	parts.append("tired" if needs.fatigue > 0.55 else "mobile")
	parts.append("curious" if needs.curiosity > 0.55 and needs.energy > 0.38 else "cautious")
	return _join_parts(parts)


func score_action(action: String, context: String) -> float:
	return float(q_table.get(_q_key(context, action), 0.0)) + float(action_preferences.get(action, 0.0)) * 0.15


func learn(decision: Dictionary, reward: float, next_context: String) -> void:
	var action := str(decision.get("action", "explore"))
	var context := str(decision.get("context", next_context))
	var key := _q_key(context, action)
	var old_value := float(q_table.get(key, 0.0))
	var best_next := -INF
	for next_action in ACTIONS:
		best_next = max(best_next, float(q_table.get(_q_key(next_context, next_action), 0.0)))
	if best_next == -INF:
		best_next = 0.0
	var updated := old_value + learning_rate * (reward + discount * best_next - old_value)
	q_table[key] = clamp(updated, -3.0, 3.0)

	action_preferences[action] = lerp(float(action_preferences.get(action, 0.0)), reward, 0.035)
	reward_trace.append(reward)
	while reward_trace.size() > 140:
		reward_trace.pop_front()

	var average_reward := 0.0
	for value in reward_trace:
		average_reward += float(value)
	if reward_trace.size() > 0:
		average_reward /= float(reward_trace.size())
	if average_reward > 0.01:
		exploration_rate = max(0.05, exploration_rate * 0.998)
	else:
		exploration_rate = min(0.42, exploration_rate + 0.0005)


func snapshot() -> Dictionary:
	var recent := 0.0
	for value in reward_trace:
		recent += float(value)
	if reward_trace.size() > 0:
		recent /= float(reward_trace.size())
	return {
		"q_entries": q_table.size(),
		"exploration_rate": exploration_rate,
		"recent_reward": recent,
		"preferences": action_preferences.duplicate(true)
	}


func serialize_state() -> Dictionary:
	return {
		"q_table": q_table.duplicate(true),
		"action_preferences": action_preferences.duplicate(true),
		"reward_trace": reward_trace.duplicate(),
		"exploration_rate": exploration_rate
	}


func deserialize_state(data: Dictionary) -> void:
	if data.has("q_table") and typeof(data["q_table"]) == TYPE_DICTIONARY:
		q_table = data["q_table"]
	if data.has("action_preferences") and typeof(data["action_preferences"]) == TYPE_DICTIONARY:
		action_preferences = data["action_preferences"]
	if data.has("reward_trace") and typeof(data["reward_trace"]) == TYPE_ARRAY:
		reward_trace = data["reward_trace"]
	exploration_rate = float(data.get("exploration_rate", exploration_rate))


func _q_key(context: String, action: String) -> String:
	return "%s::%s" % [context, action]


func _join_parts(parts: Array) -> String:
	var out := ""
	for i in range(parts.size()):
		if i > 0:
			out += "|"
		out += str(parts[i])
	return out
