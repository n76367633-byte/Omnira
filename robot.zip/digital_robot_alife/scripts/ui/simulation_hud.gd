class_name SimulationHUD
extends Control

var robot_status: Dictionary = {}
var world_status: Dictionary = {}
var paused := false
var simulation_speed := 1.0


func set_status(robot: Dictionary, world: Dictionary, is_paused: bool, speed: float) -> void:
	robot_status = robot
	world_status = world
	paused = is_paused
	simulation_speed = speed
	queue_redraw()


func _draw() -> void:
	if robot_status.is_empty():
		return
	var panel := Rect2(Vector2(18, 18), Vector2(340, 304))
	draw_rect(panel, Color8(2, 8, 16, 210), true)
	draw_rect(panel, Color8(70, 110, 135, 110), false, 1.0)

	var font := get_theme_default_font()
	var x := 34.0
	var y := 44.0
	var needs: Dictionary = robot_status.get("needs", {})
	var memory: Dictionary = robot_status.get("memory", {})
	var learning: Dictionary = robot_status.get("learning", {})
	var action := str(robot_status.get("action", "wake"))
	var mode := "paused" if paused else "living"

	_text(font, Vector2(x, y), "DIGITAL ORGANISM  //  " + mode, 13, Color8(155, 214, 230))
	y += 26.0
	_text(font, Vector2(x, y), "action: %s  speed: %.2fx" % [action, simulation_speed], 13, Color8(214, 229, 236))
	y += 22.0
	_text(font, Vector2(x, y), "reward: %.3f  explore: %.2f" % [float(robot_status.get("reward", 0.0)), float(learning.get("exploration_rate", 0.0))], 13, Color8(178, 203, 215))
	y += 24.0

	_bar(font, x, y, "energy", float(needs.get("energy", 0.0)), Color8(90, 226, 172))
	y += 22.0
	_bar(font, x, y, "stress", float(needs.get("stress", 0.0)), Color8(220, 105, 95))
	y += 22.0
	_bar(font, x, y, "damage", float(needs.get("damage", 0.0)), Color8(235, 78, 86))
	y += 22.0
	_bar(font, x, y, "curiosity", float(needs.get("curiosity", 0.0)), Color8(145, 170, 255))
	y += 22.0
	_bar(font, x, y, "confidence", float(needs.get("confidence", 0.0)), Color8(104, 204, 230))
	y += 22.0
	_bar(font, x, y, "adaptation", float(needs.get("adaptation_level", 0.0)), Color8(210, 190, 110))
	y += 28.0

	_text(font, Vector2(x, y), "memory cells: %d  q entries: %d" % [int(memory.get("known_cells", 0)), int(learning.get("q_entries", 0))], 13, Color8(188, 210, 220))
	y += 21.0
	_text(font, Vector2(x, y), "world age: %.1f  light: %.2f" % [float(world_status.get("age", 0.0)), float(world_status.get("light", 0.0))], 13, Color8(188, 210, 220))
	y += 21.0
	_text(font, Vector2(x, y), "weather: %s  resources: %d" % [str(world_status.get("weather", "clear")), int(world_status.get("resource_count", 0))], 13, Color8(188, 210, 220))


func _bar(font: Font, x: float, y: float, label: String, value: float, color: Color) -> void:
	value = clamp(value, 0.0, 1.0)
	_text(font, Vector2(x, y + 13.0), label, 12, Color8(178, 202, 214))
	var rect := Rect2(Vector2(x + 92.0, y + 2.0), Vector2(184.0, 10.0))
	draw_rect(rect, Color8(20, 34, 45, 210), true)
	draw_rect(Rect2(rect.position, Vector2(rect.size.x * value, rect.size.y)), color, true)
	draw_rect(rect, Color8(95, 135, 155, 130), false, 1.0)
	_text(font, Vector2(x + 286.0, y + 13.0), "%.2f" % value, 12, Color8(200, 220, 228))


func _text(font: Font, position: Vector2, text: String, size: int, color: Color) -> void:
	draw_string(font, position, text, HORIZONTAL_ALIGNMENT_LEFT, 310.0, size, color)
